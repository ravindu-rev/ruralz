import sys, os
root = sys.argv[1]


def edit(name, pairs):
    p = os.path.join(root, name)
    s = open(p, encoding='utf-8').read()
    for old, new in pairs:
        if s.count(old) != 1:
            raise SystemExit('%s: %d matches for %s' % (name, s.count(old), old[:120]))
        s = s.replace(old, new)
    open(p, 'w', encoding='utf-8', newline='\n').write(s)


edit('working_test.go', [
    ('''// growthSizes returns the counts TestGrowthCharges replays: every count up
// to 4,096, past which append grows a slice by a quarter, and the counts
// just past each capacity append grows a slice of 8-byte items to, up to
// 2^21 items.
func growthSizes() []int {
	var sizes []int
	for n := 1; n <= 4096; n++ {
		sizes = append(sizes, n)
	}
	var s []int
	for len(s) < 1<<21 {
		old := cap(s)
		s = append(s, 0)
		if c := cap(s); c != old && old > 4096 {
			sizes = append(sizes, old+1)
		}
	}
	return sizes
}

''', '''// growthItems is how many items TestGrowthCharges grows each list to.
const growthItems = 1 << 21

// checkGrowth replays a list of E grown by appending to growthItems items
// and checks, at every count n, the largest pair of arrays live at once so
// far against charge(n) and listGrowthBytes, and the last array against
// kept(n).
func checkGrowth[E any](t *testing.T, name string, charge, kept func(n int64) int64) {
	t.Helper()
	var s []E
	var zero E
	var pair int64
	for len(s) < growthItems {
		old := cap(s)
		s = append(s, zero)
		if c := cap(s); c != old {
			pair = max(pair, arrayBytes[E](old)+arrayBytes[E](c))
		}
		n := int64(len(s))
		if most := charge(n) + listGrowthBytes; pair > most {
			t.Fatalf("a list of %d %s held %d bytes while it grew, charged %d and listGrowthBytes", n, name, pair, charge(n))
		}
		if last := arrayBytes[E](cap(s)); last > kept(n) {
			t.Fatalf("a list of %d %s holds %d bytes, charged %d", n, name, last, kept(n))
		}
	}
}

'''),
    ('''	slot := decideErrorBytes - validationErrorBytes()
	for _, n := range growthSizes() {
		items := int64(n)
		for _, l := range []struct {
			name         string
			pair, last   int64
			charge, kept int64
		}{
			{"matching items", appendPair[int](n), lastArray[int](n), listedItems(items) * matchedItemBytes, listedItems(items) * keptItemBytes},
			{"undeclared names", appendPair[string](n), lastArray[string](n), items * listedNameBytes, items * listedNameBytes},
			// The first array of a single error's list is one of the
			// evaluation's own records (stackBytes).
			{"errors", appendPair[*sjs.ValidationError](n), lastArray[*sjs.ValidationError](max(n, 2)), max(items, 2) * slot, max(items, 2) * slot},
		} {
			if l.pair > l.charge+listGrowthBytes {
				t.Errorf("a list of %d %s held %d bytes while it grew, charged %d and listGrowthBytes", n, l.name, l.pair, l.charge)
			}
			if l.last > l.kept {
				t.Errorf("a list of %d %s holds %d bytes, charged %d", n, l.name, l.last, l.kept)
			}
		}
	}''', '''	checkGrowth[int](t, "matching items",
		func(n int64) int64 { return listedItems(n) * matchedItemBytes },
		func(n int64) int64 { return listedItems(n) * keptItemBytes })
	checkGrowth[string](t, "undeclared names",
		func(n int64) int64 { return n * listedNameBytes },
		func(n int64) int64 { return n * listedNameBytes })
	// The first array of a single error's list is one of the evaluation's
	// own records (stackBytes).
	slot := decideErrorBytes - validationErrorBytes()
	checkGrowth[*sjs.ValidationError](t, "errors",
		func(n int64) int64 { return max(n, 2) * slot },
		func(n int64) int64 { return max(n, 2) * slot })'''),
])

edit('meter_test.go', [
    ('''// lastArray returns what the last array of a slice of E grown to n items
// by appending takes (arrayBytes).
func lastArray[E any](n int) int64 {
	var s []E
	var zero E
	for len(s) < n {
		s = append(s, zero)
	}
	return arrayBytes[E](cap(s))
}

''', ''),
])
print('ok')
