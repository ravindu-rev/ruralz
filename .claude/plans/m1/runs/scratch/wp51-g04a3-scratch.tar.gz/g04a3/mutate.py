"""Mutation battery for G04 (GC-08) attempt 3.

Each mutant replaces one string, which must occur exactly once, in a copy
of a package file kept in the scratch directory, and runs the named tests
through go test -overlay with CGO_ENABLED=0. A mutant is killed when the
tests fail (not when the build fails, which is reported apart).

Usage: mutate.py OUT_DIR [NAME ...]
"""
import json
import os
import subprocess
import sys

REPO = 'C:/Users/ravin/Projects/Ruralz'
PKG = REPO + '/internal/filter/validation/jsonschema'
OUT = sys.argv[1]
ONLY = set(sys.argv[2:])

MUTANTS = [
    # Model (working.go).
    ('P01_dup16', 'working.go', 'dupItemBytes = 192', 'dupItemBytes = 16',
     '^(TestWorkingSetCoversPeak|TestHandleMeasuredFit|TestGrowthCharges)$'),
    ('P02_names0', 'working.go', 'own = addCap(own, namesBytes(n))', 'own = addCap(own, 0)',
     '^TestWorkingSetCoversPeak$'),
    ('P03_namesNoRounding', 'working.go', '\treturn addCap(b, stringExtra(b))\n', '\treturn mulCap(n, hashNameBytes)\n',
     '^TestCopySizes$'),
    ('P04_copyNoRounding', 'working.go', '\treturn n + stringExtra(n)\n}\n\n// mallocHeaderBytes', '\treturn n\n}\n\n// mallocHeaderBytes',
     '^TestCopySizes$'),
    ('P05_copyShort', 'working.go', '\tcase n < tinyBlockBytes:\n\t\treturn tinyBlockBytes\n\t}\n\treturn n + stringExtra(n)',
     '\tcase n < tinyBlockBytes:\n\t\treturn n\n\t}\n\treturn n + stringExtra(n)',
     '^(TestCopySizes|TestWorkingSetCharges)$'),
    ('P06_noCopyTransient', 'working.go', 'b.transient = max(b.transient, copyBytes(n))', 'b.transient = max(b.transient, 0)',
     '^(TestWorkingSetCoversPeak|TestHandleAcceptsLargeBodies|TestWorkingSetCharges)$'),
    ('P07_listed0', 'working.go', 'listedNameBytes = 48', 'listedNameBytes = 0',
     '^(TestWorkingSetCoversPeak|TestGrowthCharges)$'),
    ('P08_matched16', 'working.go', 'matchedItemBytes, keptItemBytes = 24, 16', 'matchedItemBytes, keptItemBytes = 16, 16',
     '^TestGrowthCharges$'),
    ('P09_kept8', 'working.go', 'matchedItemBytes, keptItemBytes = 24, 16', 'matchedItemBytes, keptItemBytes = 24, 8',
     '^TestGrowthCharges$'),
    ('P10_listedItemsN', 'working.go', '\treturn max(n, 2)\n}', '\treturn n\n}',
     '^TestGrowthCharges$'),
    ('P11_growth0', 'working.go', 'listGrowthBytes = 256', 'listGrowthBytes = 0',
     '^TestGrowthCharges$'),
    ('P12_walk0', 'working.go', 'max(addCap(b.path, b.transient), walkBytes(b.ws.flags.maxPointer))', 'addCap(b.path, b.transient)',
     '^TestHandleWalkMemory$'),
    ('P13_walk1', 'working.go', '\treturn 4 * (n + stringExtra(n))', '\treturn n + stringExtra(n)',
     '^TestHandleWalkMemory$'),
    ('P14_errorSlot16', 'working.go', 'decideErrorBytes = 104', 'decideErrorBytes = 96',
     '^TestGrowthCharges$'),
    ('P15_propMap64', 'working.go', 'propMapBase, propMapEntry = 256, 128', 'propMapBase, propMapEntry = 256, 64',
     '^TestGrowthCharges$'),
    ('P16_itemMap48', 'working.go', 'itemMapBase, itemMapEntry = 192, 96', 'itemMapBase, itemMapEntry = 192, 48',
     '^TestGrowthCharges$'),
    # Harness (meter_test.go).
    ('H01_noEntryCopies', 'meter_test.go', '\ts.copies(v)\n\tm.entries++', '\tm.entries++',
     '^(TestWorkingSetCoversPeak|TestHeapMeter)$'),
    ('H02_noEntryMarks', 'meter_test.go', 'if !m.dueProbe(m.entries) || m.only != "" {', 'if m.dueProbe(m.entries) || true {',
     '^TestHeapMeter$'),
    ('H03_noTrueProbes', 'meter_test.go', 'if !v || flagPosition(w, ptr) {', 'if true {',
     '^(TestHeapMeter|TestWorkingSetCoversPeak)$'),
    ('H04_noDuplicates', 'meter_test.go', 'm.copy(copyDuplicates, m.duplicatesCopy(v))', 'm.copy(copyDuplicates, 0)',
     '^(TestWorkingSetCoversPeak|TestHeapMeter)$'),
    ('H05_noListed', 'meter_test.go', 'm.copy(copyListed, appendPair[string](s.undeclared(v)))', 'm.copy(copyListed, 0)',
     '^TestWorkingSetCoversPeak$'),
    ('H06_noDropped', 'meter_test.go', 'm.copy(copyDropped, droppedErrors(len(arr), len(ctx.ValueLocation())))', 'm.copy(copyDropped, 0)',
     '^TestWorkingSetCoversPeak$'),
    ('H07_noNumbers', 'meter_test.go', '\t\tm.copy(copyNumber, numberCheckBytes)', '\t\tm.copy(copyNumber, 0)',
     '^(TestWorkingSetCoversPeak|TestHeapMeter)$'),
    ('H08_noWalk', 'meter_test.go', '\treturn most + best\n}', '\treturn 0\n}',
     '^TestHandleWalkMemory$'),
    ('H09_noJobRecord', 'meter_test.go', 'jobs >= 0 && seen && jobs <= most', 'jobs >= 0 && seen',
     '^TestHeapMeter$'),
    ('H10_nfaUnmetered', 'meter_test.go', 'jobs >= 0 && seen && jobs <= most', 'seen && jobs <= most',
     '^TestHeapMeter$'),
    ('H11_noLocationEnd', 'meter_test.go', 'return map[string]any{"$ref": baseURL, "x-probe-end": locationEnd}', 'return map[string]any{"$ref": baseURL}',
     '^(TestWorkingSetCoversPeak|TestHeapMeter)$'),
    ('H12_noKindHeads', 'meter_test.go', 'return due(m.probes, &m.nextProbe) || n <= probeHead', 'return due(m.probes, &m.nextProbe)',
     '^(TestHeapMeter|TestHandleBoundsUnevaluatedMemory)$'),
    ('H13_copiesOffPeak', 'meter_test.go', 'return max(addCap(growth(m.live, m.base), m.transient), m.matched)', 'return max(growth(m.live, m.base), m.matched)',
     '^TestHeapMeter$'),
    ('H14_noFirstDuplicate', 'meter_test.go', '\t\tif seen[key] {\n\t\t\tbreak\n\t\t}', '\t\tif seen[key] {\n\t\t\tcontinue\n\t\t}',
     '^TestDuplicatesReplica$'),
    ('H15_hashSigned', 'meter_test.go', '\t\t\tb.Write(r.Num().Bytes())', '\t\t\tb.WriteString(r.Num().String())',
     '^TestDuplicatesReplica$'),
    ('H16_noSortedNames', 'meter_test.go', 'return pointerSlice(len(t), 16) + below', 'return below',
     '^TestWorkingSetCoversPeak$'),
    ('H17_noHeader', 'meter_test.go', '\tif bytes > 512 {\n\t\tbytes += mallocHeaderBytes\n\t}\n\treturn allocSize(bytes)', '\treturn allocSize(bytes)',
     '^TestCopySizes$'),
    ('H18_copyUnrounded', 'meter_test.go', '\treturn allocSize(int64(n))\n}', '\treturn int64(n)\n}',
     '^TestCopySizes$'),
    ('H19_pairNewOnly', 'meter_test.go', '\t\t\tpair = max(pair, arrayBytes[E](old)+arrayBytes[E](c))\n\t\t}\n\t}\n\treturn pair',
     '\t\t\tpair = max(pair, arrayBytes[E](c))\n\t\t}\n\t}\n\treturn pair',
     '^TestGrowthCharges$'),
    ('H06b_noDropped', 'meter_test.go', 'm.copy(copyDropped, droppedErrors(len(arr), len(ctx.ValueLocation())))', 'm.copy(copyDropped, 0*int64(len(arr)))',
     '^TestWorkingSetCoversPeak$'),
    ('H09b_noJobRecord', 'meter_test.go', 'jobs >= 0 && seen && jobs <= most', 'jobs >= 0 && seen && most >= 0',
     '^TestHeapMeter$'),
    ('P17_hashName0', 'working.go', 'hashNameBytes = 16', 'hashNameBytes = 0',
     '^TestWorkingSetCoversPeak$'),
    # How the memory tests run (requireMeter) and the schedule.
    ('G01_noPin', 'meter_test.go', '\tprocs := runtime.GOMAXPROCS(1)\n\tt.Cleanup(func() { runtime.GOMAXPROCS(procs) })\n', '',
     '^TestRequireMeter$'),
    ('G02_noRestore', 'meter_test.go', '\tt.Cleanup(func() { runtime.GOMAXPROCS(procs) })\n', '\t_ = procs\n',
     '^TestRequireMeter$'),
    ('G03_noRaceSkip', 'meter_test.go', '\tif raceEnabled {\n\t\tt.Skip("the live heap is not measured under -race: the detector changes what the library allocates")\n\t}\n', '',
     '^TestRequireMeter$', ['-race']),
    ('H13b_copiesOffPeak', 'meter_test.go', 'return max(addCap(growth(m.live, m.base), m.transient), m.matched)', 'return max(growth(m.live, m.base), m.matched)',
     '^TestWorkingSetCoversPeak$'),
    ('H20_halfSchedule', 'meter_test.go', 'const probeHead, probeGrowth = 8, 4', 'const probeHead, probeGrowth = 4, 2',
     '^TestHeapMeter$'),
]


def run(name, fname, old, new, tests, flags=()):
    src = os.path.join(PKG, fname)
    text = open(src, encoding='utf-8').read()
    count = text.count(old)
    if count != 1:
        return 'BAD', '%d matches' % count
    d = os.path.join(OUT, name)
    os.makedirs(d, exist_ok=True)
    mutated = os.path.join(d, fname)
    open(mutated, 'w', encoding='utf-8', newline='\n').write(text.replace(old, new))
    overlay = os.path.join(d, 'overlay.json')
    json.dump({'Replace': {src.replace('\\', '/'): mutated.replace('\\', '/')}}, open(overlay, 'w'))
    env = dict(os.environ, CGO_ENABLED='1' if '-race' in flags else '0')
    p = subprocess.run(['go', 'test', *flags, '-overlay', overlay, '-count=1', '-run', tests, '-timeout', '60m',
                        './internal/filter/validation/jsonschema/'], cwd=REPO, env=env,
                       capture_output=True, text=True)
    out = p.stdout + p.stderr
    open(os.path.join(d, 'out.txt'), 'w', encoding='utf-8').write(out)
    if p.returncode == 0:
        return 'SURVIVED', ''
    if '--- FAIL' in out:
        fails = [l.strip() for l in out.splitlines() if l.strip().startswith('--- FAIL')]
        return 'KILLED', '; '.join(fails[:6])
    return 'ERROR', out[-400:]


results = []
for m in MUTANTS:
    if ONLY and m[0] not in ONLY:
        continue
    status, detail = run(*m)
    line = '%s %s %s' % (m[0], status, detail)
    print(line, flush=True)
    results.append(line)
open(os.path.join(OUT, 'results.txt'), 'a', encoding='utf-8').write('\n'.join(results) + '\n')
