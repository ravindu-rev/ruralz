import sys, os
root = sys.argv[1]


def edit(name, pairs):
    p = os.path.join(root, name)
    s = open(p, encoding='utf-8').read()
    for old, new in pairs:
        if s.count(old) != 1:
            raise SystemExit('%s: %d matches for %s' % (name, s.count(old), old[:120]))
        s = s.replace(old, new)
    open(p, 'w', encoding='utf-8', newline='\n').write(s)


edit('doc.go', [
    ('''//     failing member name's under each evaluation with propertyNames, and
//     at an array 16 bytes per item for each evaluation with minContains or
//     maxContains, whose error keeps the index of every item that matches
//     contains (review finding: 100 such evaluations over 16,000 items held
//     12.7 MB charged 58 KB);''', '''//     failing member name's under each evaluation with propertyNames, and
//     at an array 16 bytes per item, at least two, for each evaluation with
//     minContains or maxContains, whose error keeps the last array of its
//     list of the items that match contains (review finding: 100 such
//     evaluations over 16,000 items held 12.7 MB charged 58 KB);'''),
    ('''//     chain, up to three times that while the stack doubles and copies;
//     the decision pass's wrapper adds three; TestStackWithinCharge); per
//     evaluation of that chain that may copy unevaluated names, a map of''', '''//     chain, up to three times that while the stack doubles and copies;
//     the decision pass's wrapper adds three; TestStackWithinCharge), which
//     leaves room for the records an evaluation keeps on the heap while it
//     runs, its validator, scope and unevaluated record and the first
//     array of its error list, about 230 bytes; per
//     evaluation of that chain that may copy unevaluated names, a map of'''),
    ('''//     refused a 49 KB object, TestHandleUnevaluatedBranches); per
//     evaluation with additionalProperties false 48 bytes per member it may
//     list; and per evaluation with contains 16 bytes per item for the
//     indexes of the items that match, which it lists while it loops;''', '''//     refused a 49 KB object, TestHandleUnevaluatedBranches); per
//     evaluation with additionalProperties false 48 bytes per member it may
//     list, and with contains 24 bytes per item, at least two, for the
//     indexes of the items that match, which it lists while it loops: three
//     times a name's or an index's bytes, the old array live beside the new
//     while append copies the list (audit class GC-08: charged twice the
//     index, one list just grown past a capacity held up to 23.9 bytes per
//     item, TestGrowthCharges); per object that a uniqueItems pass hashes,
//     the sorted slice of its names, 16 bytes a name at the slice's
//     allocation size; and once, 256 bytes for the one list a pass grows
//     at a time, whose new array the allocator's size classes and headers
//     round up past its items' charges;'''),
    ('''//   - once, the largest transient copy: the longest string, which the
//     library copies at every evaluation, the duplicates map of the longest
//     uniqueItems array (192 bytes per item, measured 102 to 168), or a''', '''//   - once, the largest transient copy: the copy of the longest string,
//     which the library makes at every evaluation, at its allocation size
//     (audit class GC-08: charged its bytes, a 100,000-byte string's copy
//     took 106,496, TestCopySizes), the duplicates map of the longest
//     uniqueItems array (192 bytes per item; it holds about 58 and
//     allocates up to 187 while it grows, TestGrowthCharges), or a'''),
    ('''//     pattern does (proposed, an accepted consequence; matching with the
//     NFA simulation alone would remove it, at two to nine times the time
//     of the backtracker on such strings).
//''', '''//     pattern does (proposed, an accepted consequence; matching with the
//     NFA simulation alone would remove it, at two to nine times the time
//     of the backtracker on such strings);
//   - in the location pass, at least what its walk over the error tree
//     holds once the pass has returned and dropped its path and transient
//     copies: four pointers of the document's longest location and keyword
//     at their allocation size (walkBytes; review finding, audit class
//     GC-08: a body of one byte failing under a $defs name of 100,000
//     bytes held 106 KB in the walk, while 41 KB were reserved for it,
//     TestHandleWalkMemory).
//'''),
    ('''// TestWorkingSetCoversPeak measures the error trees exactly, the decision
// pass's at its end, for dense failing bodies of every error shape, along
// reference chains and for ordinary order bodies: they stayed within 0.89 of
// the charge in either pass. It measures the live heap at the peak of each
// pass too, with the copies and the matcher's state, deterministically but
// for what the runtime itself allocates meanwhile (a thread it starts under
// load, 5.3 KB; the tests allow 16 KiB): at probes it adds to the deepest
// evaluations of the pass's first path, to evaluations spread over the rest
// of it and to its end, and at its matches, the matcher's own peak computed
// from the match's allocations (audit class GC-08: a sample of the heap in
// use, which this replaces, counts the garbage the library drops, under load
// up to 1.64 times the charge of the unevaluated indexes under branches
// whose live heap stays within 0.38 of it; and marks at the first
// evaluations alone missed the tree a failing body's decision pass grows to
// its end, the library running a schema's extension keywords after its
// applicators failed). The live peak stayed within 0.88 of the pass's whole
// working set in either pass, and a pass that holds its error tree and one
// path's copies at once holds more than either term
// (TestDecisionTreeBesideCopies). The decision pass is charged its worst''', '''// TestWorkingSetCoversPeak measures the error trees exactly, the decision
// pass's at its end, for dense failing bodies of every error shape, along
// reference chains, for ordinary order bodies and for bodies whose
// evaluations make copies and drop them: the dense trees stayed within 0.89
// of the charge in either pass. It measures the live heap at the peak of
// each pass too, deterministically but for what the runtime itself
// allocates meanwhile (a thread it starts under load, 5.3 KB; the tests
// allow 16 KiB): it collects the heap fully where the library calls a
// test's probe, at the start of evaluations and at the end of those that
// reach their extension keywords, at the first of them in a pass, at others
// spread over the rest of it and at its end, and at its matches, whose
// matcher's own peak it computes from the match's allocations; what the
// library copies and drops between two such calls is replayed, the largest
// copy added to the largest live heap as the model adds its transient copy:
// a string's copy, the uniqueItems duplicates map, whose replica allocates
// exactly what the library's does (TestDuplicatesReplica), with the names
// it sorts, the names additionalProperties false lists, the errors a
// contains loop over false drops, the location walk's pointers and,
// bounded at 16 KiB within the number bounds, a number check's rationals
// (TestNumberCheckMemory). A list or a map also holds its old array or
// table besides the new one while it grows: TestGrowthCharges replays every
// growth against its charge, and TestCopySizes every copy's allocation size
// (audit class GC-08: a sample of the heap in use, which this replaces,
// counts the garbage the library drops, under load up to 1.64 times the
// charge of the unevaluated indexes under branches whose live heap stays
// within 0.38 of it; marks at the first evaluations alone missed the tree a
// failing body's decision pass grows to its end, the library running a
// schema's extension keywords after its applicators failed; and marks at
// the end of evaluations alone missed every copy, the duplicates map of a
// valid uniqueItems array, about 58 bytes per item, among them, and the
// evaluations of true and those that fail before their end). The live peak
// stayed within 0.88 of the pass's whole working set in either pass, 0.96
// for the sorted names of a wide object, which are most of its charge, and
// a pass that holds its error tree and one path's copies at once holds
// more than either term (TestDecisionTreeBesideCopies). The decision pass is
// charged its worst'''),
    ('''// The reservation covers the live heap at Handle's peak for every shape
// above, measured at the reservation, at probes in the deepest evaluations
// of each pass's first path, in evaluations spread over the rest of it and
// at its end, and at its matches with the matcher's own peak (audit class
// GC-08; a sample of the heap in use, which this replaces, also counted the
// tables a wide object's map outgrew and the arrays the decoder outgrew,
// garbage before anything is reserved). For records and arrays of small
// objects the reservation is 1.0 to 1.6 times that peak, the decoded tree
// being most of both; for long strings, conditional records and timestamp
// pairs 2; for dense numeric and enum arrays at the working-set limit 3.7 to
// 4.5, and for uniqueItems arrays 6 to 8.6, charged errors and duplicates
// maps a valid body does not hold; for compositions, unions and recursive
// documents 3.2 to 18 at the sizes above, and up to about 115 for the
// component tree nested 6 deep.''', '''// The reservation covers the live heap at Handle's peak for every shape
// above, measured as TestWorkingSetCoversPeak measures it and at the
// reservation (audit class GC-08; a sample of the heap in use, which this
// replaces, also counted the tables a wide object's map outgrew and the
// arrays the decoder outgrew, garbage before anything is reserved, and
// marks at the end of evaluations alone left out the uniqueItems
// duplicates map and a long string's copy). For records and arrays of
// small objects the reservation is 1.3 to 1.6 times that peak, the decoded
// tree being most of both; for long strings 1.0, the string's copy as
// large as the string; for conditional records and timestamp pairs 2; for
// uniqueItems arrays 2.4 to 2.7, charged 192 bytes per item for duplicates
// maps that hold about 58; for dense numeric and enum arrays at the
// working-set limit 3.7 to 4.5, charged errors a valid body does not hold;
// for compositions, unions and recursive documents 3.2 to 18 at the sizes
// above, and up to about 114 for the component tree nested 6 deep.'''),
])
print('ok')
