module capprobe

go 1.26
