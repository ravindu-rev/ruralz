package main

import (
	"fmt"
	"runtime"
)

type E struct{ a, b, c, d, e, f, g, h, i, j uint64 }

func main() {
	var a []int
	var p []*E
	var s []string
	var b []byte
	fmt.Println(runtime.Version())
	for i := 0; i < 70; i++ {
		ca, cp, cs := cap(a), cap(p), cap(s)
		a = append(a, i)
		p = append(p, nil)
		s = append(s, "")
		if cap(a) != ca || cap(p) != cp || cap(s) != cs {
			fmt.Println(i+1, cap(a), cap(p), cap(s))
		}
	}
	b = append(b, 1)
	fmt.Println("bytes", cap(b))
}
