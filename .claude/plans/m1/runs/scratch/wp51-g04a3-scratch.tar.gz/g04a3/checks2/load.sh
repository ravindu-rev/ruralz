#!/bin/bash
# Samples the machine's CPU load every 15 s into $1 until $2 exists.
while [ ! -e "$2" ]; do
	echo "$(date +%T) $(powershell.exe -NoProfile -Command '(Get-CimInstance Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average' 2>/dev/null | tr -d '\r')" >> "$1"
	sleep 15
done
