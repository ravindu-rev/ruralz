#!/bin/bash
# The three required suites at once, as the check runs them: the race run
# with go test's default timeout, beside the cgo-off and floor suites.
S=/c/Users/ravin/AppData/Local/Temp/claude/c--Users-ravin-Projects-Ruralz/5104a226-9733-4230-8cf6-a5ff30e79ceb/scratchpad/wp51close/g04a3/checks2
TAG=${1:-trial}
cd /c/Users/ravin/Projects/Ruralz
( time go test -race -count=1 -cover -shuffle=on ./internal/filter/validation/jsonschema/... ) > $S/$TAG.race.out 2>&1 &
r=$!
( time CGO_ENABLED=0 go test -count=1 ./internal/filter/validation/jsonschema/... ) > $S/$TAG.cgooff.out 2>&1 &
c=$!
( time GOTOOLCHAIN=go1.26.8 GOEXPERIMENT=jsonv2 CGO_ENABLED=0 go test -count=1 ./internal/filter/validation/jsonschema/... ) > $S/$TAG.floor.out 2>&1 &
f=$!
wait $r $c $f
for x in race cgooff floor; do echo "== $x"; grep -E "^(ok|FAIL|---|panic)|real" $S/$TAG.$x.out | head -8; done
