import sys, os
root = sys.argv[1]


def edit(name, pairs):
    p = os.path.join(root, name)
    s = open(p, encoding='utf-8').read()
    for old, new in pairs:
        if s.count(old) != 1:
            raise SystemExit('%s: %d matches for %s' % (name, s.count(old), old[:120]))
        s = s.replace(old, new)
    open(p, 'w', encoding='utf-8', newline='\n').write(s)


edit('meter_test.go', [
    ('''// arrayBytes returns what an array of n items of E, at a capacity append
// grew a slice to, takes: its bytes, with the header the allocator puts in
// front of it past 512 bytes when E holds pointers.
func arrayBytes[E any](n int) int64 {
	typ := reflect.TypeFor[E]()
	bytes := int64(n) * int64(typ.Size())
	if pointers := typ.Kind() == reflect.String || typ.Kind() == reflect.Pointer; pointers && bytes > 512 {
		bytes += mallocHeaderBytes
	}
	return bytes
}''', '''// arrayBytes returns what an array of n items of E takes: its allocation
// size (allocSize), with the header the allocator puts in front of it past
// 512 bytes when E holds pointers.
func arrayBytes[E any](n int) int64 {
	typ := reflect.TypeFor[E]()
	bytes := int64(n) * int64(typ.Size())
	if pointers := typ.Kind() == reflect.String || typ.Kind() == reflect.Pointer; pointers && bytes > 512 {
		bytes += mallocHeaderBytes
	}
	return allocSize(bytes)
}

// allocSize returns what the allocator takes for an object of n bytes: its
// size class, or whole pages past 32 KiB, as append rounds a byte slice up
// (runtime roundupsize).
func allocSize(n int64) int64 {
	if n <= 0 {
		return 0
	}
	return int64(cap(append([]byte(nil), make([]byte, n)...)))
}'''),
    ('''	case n < tinyBlockBytes:
		return tinyBlockBytes
	}
	return int64(cap(append([]byte(nil), make([]byte, n)...)))
}''', '''	case n < tinyBlockBytes:
		return tinyBlockBytes
	}
	return allocSize(int64(n))
}'''),
    ('''// pointerSlice returns what a slice of n items of size bytes holding
// pointers takes, made at that length (make, slices.Clone): its allocation
// size, which append's growth to n rounds to, with the header the
// allocator puts in front of it past 512 bytes.
func pointerSlice(n int, size int64) int64 {
	if n == 0 {
		return 0
	}
	bytes := int64(cap(append([]string(nil), make([]string, (int64(n)*size+15)/16)...))) * 16
	if bytes > 512 {
		bytes += mallocHeaderBytes
	}
	return bytes
}''', '''// pointerSlice returns what a slice of n items of size bytes holding
// pointers takes, made at that length (make, slices.Clone): its bytes with
// the header the allocator puts in front of them past 512 bytes, at their
// allocation size (allocSize).
func pointerSlice(n int, size int64) int64 {
	bytes := int64(n) * size
	if bytes > 512 {
		bytes += mallocHeaderBytes
	}
	return allocSize(bytes)
}'''),
])

edit('working_test.go', [
    ('''	var s []E
	var zero E
	var pair int64
	for len(s) < growthItems {
		old := cap(s)
		s = append(s, zero)
		if c := cap(s); c != old {
			pair = max(pair, arrayBytes[E](old)+arrayBytes[E](c))
		}
		n := int64(len(s))
		if most := charge(n) + listGrowthBytes; pair > most {
			t.Fatalf("a list of %d %s held %d bytes while it grew, charged %d and listGrowthBytes", n, name, pair, charge(n))
		}
		if last := arrayBytes[E](cap(s)); last > kept(n) {
			t.Fatalf("a list of %d %s holds %d bytes, charged %d", n, name, last, kept(n))
		}
	}''', '''	var s []E
	var zero E
	var pair, last int64
	for len(s) < growthItems {
		old := cap(s)
		s = append(s, zero)
		if c := cap(s); c != old {
			last = arrayBytes[E](c)
			pair = max(pair, arrayBytes[E](old)+last)
		}
		n := int64(len(s))
		if most := charge(n) + listGrowthBytes; pair > most {
			t.Fatalf("a list of %d %s held %d bytes while it grew, charged %d and listGrowthBytes", n, name, pair, charge(n))
		}
		if last > kept(n) {
			t.Fatalf("a list of %d %s holds %d bytes, charged %d", n, name, last, kept(n))
		}
	}'''),
])

p = os.path.join(root, 'working_test.go')
s = open(p, encoding='utf-8').read()
s += open(sys.argv[2], encoding='utf-8').read()
open(p, 'w', encoding='utf-8', newline='\n').write(s)
print('ok')
