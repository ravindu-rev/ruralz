import os
import sys

root = sys.argv[1]


def edit(name, pairs):
    p = os.path.join(root, name)
    s = open(p, encoding='utf-8').read()
    for old, new in pairs:
        if s.count(old) != 1:
            raise SystemExit('%s: %d matches for %r' % (name, s.count(old), old[:100]))
        s = s.replace(old, new)
    open(p, 'w', encoding='utf-8', newline='\n').write(s)


edit('meter_test.go', [
    ('''// end mark. Each mark collects the heap twice, so the marks of a pass
// grow with the logarithm of its probes alone. The goroutine's stack is
// not heap: TestStackWithinCharge measures it.''', '''// end mark. Each mark collects the heap twice, so the marks of a pass
// grow only with the logarithm of its probes. The goroutine's stack is
// not heap: TestStackWithinCharge measures it.'''),
])

edit('doc.go', [
    ('''// thread it starts under load, 5.3 KB, which the tests' one processor never
// saw; they allow 16 KiB): it collects the heap fully where the library calls a
// test's probe, at the start of evaluations and at the end of those that reach''', '''// thread it starts under load, 5.3 KB, which none of 54,000 measurements on the
// tests' one processor saw; the tests allow 16 KiB): it collects the heap fully
// where the library calls a test's probe, at the start of evaluations and at the
// end of those that reach'''),
])
print('ok')
