import sys, os
root = sys.argv[1]


def edit(name, pairs):
    p = os.path.join(root, name)
    s = open(p, encoding='utf-8').read()
    for old, new in pairs:
        if s.count(old) != 1:
            raise SystemExit('%s: %d matches for %s' % (name, s.count(old), old[:120]))
        s = s.replace(old, new)
    open(p, 'w', encoding='utf-8', newline='\n').write(s)


edit('working.go', [
    ('''	// stackBytes is the goroutine stack one evaluation of the chain on the
	// call stack may take (evalGraph.chain): measured at 1.4 to 1.6 KiB per
	// in-place evaluation and 2.2 to 2.5 KiB per evaluation of a nesting
	// level's chain, whose first evaluation also descends into the value
	// (debug.SetMaxStack), up to three times that while the stack doubles
	// and copies.
	stackBytes = 8192''', '''	// stackBytes is the goroutine stack one evaluation of the chain on the
	// call stack may take (evalGraph.chain): measured at 1.4 to 1.6 KiB per
	// in-place evaluation and 2.2 to 2.5 KiB per evaluation of a nesting
	// level's chain, whose first evaluation also descends into the value
	// (debug.SetMaxStack), up to three times that while the stack doubles
	// and copies. What that leaves, at least 512 bytes, holds the records
	// the evaluation keeps on the heap while it runs: the validator, its
	// scope and unevaluated record, about 200 bytes, and the first array
	// of its error list, 32 bytes for up to four errors, of which the
	// error charges count 24 bytes a slot.
	stackBytes = 8192'''),
    ('''	// keptItemBytes is what the location pass keeps per item in a
	// minContains or maxContains error: the list's last array, at most
	// twice the indexes.
	matchedItemBytes, keptItemBytes = 24, 16
)''', '''	// keptItemBytes is what the location pass keeps per item in a
	// minContains or maxContains error: the list's last array, at most
	// twice the indexes. Both count at least two items (listedItems): Go's
	// append makes the first array of a slice 32 bytes.
	matchedItemBytes, keptItemBytes = 24, 16
	// listGrowthBytes is what the one list the library grows at a time
	// holds past its items' charges while append copies it into a larger
	// array, which the allocator's size classes and headers round up
	// (TestGrowthCharges: at most 256 bytes, an error list grown past 287
	// slots): charged once to each pass.
	listGrowthBytes = 256
)

// listedItems returns the items a list of n matching items is charged
// for: none for an empty list, which allocates nothing, and at least the
// two of the first array.
func listedItems(n int64) int64 {
	if n == 0 {
		return 0
	}
	return max(n, 2)
}'''),
    ('''		own = addCap(own, mulCap(mulCap(lists, n), matchedItemBytes))
		b.locate = addCap(b.locate, mulCap(mulCap(kept, n), keptItemBytes))''', '''		own = addCap(own, mulCap(mulCap(lists, listedItems(n)), matchedItemBytes))
		b.locate = addCap(b.locate, mulCap(mulCap(kept, listedItems(n)), keptItemBytes))'''),
    ('''	b.path, b.decide = addCap(path, decideFrames*stackBytes), decide''', '''	b.path, b.decide = addCap(path, decideFrames*stackBytes+listGrowthBytes), decide'''),
])

edit('working_test.go', [
    ('''		wrapper  = decideFrames * stackBytes''', '''		wrapper  = decideFrames*stackBytes + listGrowthBytes'''),
    ('''	for _, n := range growthSizes() {
		if pair, most := appendPair[int](n), int64(n)*matchedItemBytes; pair > most {
			t.Errorf("a list of %d matching items held %d bytes while it grew, charged %d", n, pair, most)
		}
		var kept []int
		for range n {
			kept = append(kept, 0)
		}
		if last, most := int64(cap(kept))*8, int64(n)*keptItemBytes; last > most {
			t.Errorf("a kept list of %d matching items holds %d bytes, charged %d", n, last, most)
		}
		if pair, most := appendPair[string](n), int64(n)*listedNameBytes; pair > most {
			t.Errorf("a list of %d undeclared names held %d bytes while it grew, charged %d", n, pair, most)
		}
		if pair, most := appendPair[*sjs.ValidationError](n), int64(n)*(decideErrorBytes-validationErrorBytes()); pair > most {
			t.Errorf("a list of %d errors held %d bytes while it grew, charged %d besides the errors", n, pair, most)
		}
	}''', '''	slot := decideErrorBytes - validationErrorBytes()
	for _, n := range growthSizes() {
		items := int64(n)
		for _, l := range []struct {
			name         string
			pair, last   int64
			charge, kept int64
		}{
			{"matching items", appendPair[int](n), lastArray[int](n), listedItems(items) * matchedItemBytes, listedItems(items) * keptItemBytes},
			{"undeclared names", appendPair[string](n), lastArray[string](n), items * listedNameBytes, items * listedNameBytes},
			// The first array of a single error's list is one of the
			// evaluation's own records (stackBytes).
			{"errors", appendPair[*sjs.ValidationError](n), lastArray[*sjs.ValidationError](max(n, 2)), max(items, 2) * slot, max(items, 2) * slot},
		} {
			if l.pair > l.charge+listGrowthBytes {
				t.Errorf("a list of %d %s held %d bytes while it grew, charged %d and listGrowthBytes", n, l.name, l.pair, l.charge)
			}
			if l.last > l.kept {
				t.Errorf("a list of %d %s holds %d bytes, charged %d", n, l.name, l.last, l.kept)
			}
		}
	}'''),
    ('''//   - the indexes of the items an evaluation with contains matches, an
//     []int it appends to while it loops (validator.go arrValidate): at
//     most matchedItemBytes per item of the array, the largest pair of
//     arrays live at once (review finding: charged 16, the pair of a list
//     just grown past a capacity held up to 23.9 bytes per item, so one
//     list of 175,105 matching items held 3.15 MB, charged 2.8 MB), and
//     the list the location pass keeps in a minContains or maxContains
//     error, its last array, at most keptItemBytes per item;
//   - the names additionalProperties false lists, a []string (objValidate):
//     at most listedNameBytes per member;
//   - the errors an evaluation collects, a []*ValidationError (addErr): at
//     most the part of decideErrorBytes besides the error itself per error;''', '''//   - the indexes of the items an evaluation with contains matches, an
//     []int it appends to while it loops (validator.go arrValidate): at
//     most matchedItemBytes per item of the array, of at least two items
//     (listedItems), the largest pair of arrays live at once (review
//     finding: charged 16, the pair of a list just grown past a capacity
//     held up to 23.9 bytes per item, so one list of 175,105 matching
//     items held 3.15 MB, charged 2.8 MB), and the list the location pass
//     keeps in a minContains or maxContains error, its last array, at
//     most keptItemBytes per item;
//   - the names additionalProperties false lists, a []string (objValidate):
//     at most listedNameBytes per member;
//   - the errors an evaluation collects, a []*ValidationError (addErr): at
//     most the part of decideErrorBytes besides the error itself per error,
//     of at least two (a single error's list is one of the evaluation's
//     records, stackBytes);
//   - while a list grows, the allocator's size classes and the header it
//     puts in front of a large array of pointers round the new array up:
//     at most listGrowthBytes past the list's charge, charged once to a
//     pass, which grows one list at a time;'''),
])

edit('meter_test.go', [
    ('''// arrayBytes returns what an array of n items of E''', '''// lastArray returns what the last array of a slice of E grown to n items
// by appending takes (arrayBytes).
func lastArray[E any](n int) int64 {
	var s []E
	var zero E
	for len(s) < n {
		s = append(s, zero)
	}
	return arrayBytes[E](cap(s))
}

// arrayBytes returns what an array of n items of E'''),
])
print('ok')
