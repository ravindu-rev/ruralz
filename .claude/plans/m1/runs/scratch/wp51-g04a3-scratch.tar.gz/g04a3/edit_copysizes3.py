import sys, os
root = sys.argv[1]
p = os.path.join(root, 'working_test.go')
s = open(p, encoding='utf-8').read()
old = '''	// Every length of a size class, or of a run of whole pages, takes the
	// allocation of its largest: replayed once per class.
	for n := 1; n <= 1<<24; {
		got, end := stringCopy(n), tinyBlockBytes-1
		if n >= tinyBlockBytes {
			end = int(got)
		}
		for m := n; m <= end; m++ {
			if charged := copyBytes(int64(m)); got > charged {
				t.Fatalf("the copy of %d bytes takes %d, charged %d", m, got, charged)
			}
		}
		n = end + 1
	}
	for n := 1; n <= 1<<20; {
		got := pointerSlice(n, 16)
		end := int(got / 16)
		if got > 512 {
			end = int((got - mallocHeaderBytes) / 16)
		}
		for m := n; m <= end; m++ {
			if charged := namesBytes(int64(m)); got > charged {
				t.Fatalf("the sorted names of %d members take %d, charged %d", m, got, charged)
			}
		}
		n = end + 1
	}
'''
new = '''	// Every length of a size class, or of a run of whole pages, takes the
	// allocation of its largest: replayed once per class to 256 KiB, past
	// which pages round alike, and around powers of two to 16 MiB.
	copied := func(n, end int) {
		got := stringCopy(n)
		for m := n; m <= end; m++ {
			if charged := copyBytes(int64(m)); got > charged {
				t.Fatalf("the copy of %d bytes takes %d, charged %d", m, got, charged)
			}
		}
	}
	sorted := func(n, end int) {
		got := pointerSlice(n, 16)
		for m := n; m <= end; m++ {
			if charged := namesBytes(int64(m)); got > charged {
				t.Fatalf("the sorted names of %d members take %d, charged %d", m, got, charged)
			}
		}
	}
	for n := 1; n <= 256<<10; {
		end := tinyBlockBytes - 1
		if n >= tinyBlockBytes {
			end = int(stringCopy(n))
		}
		copied(n, end)
		n = end + 1
	}
	for n := 1; n <= 16<<10; {
		got := pointerSlice(n, 16)
		end := int(got / 16)
		if got > 512 {
			end = int((got - mallocHeaderBytes) / 16)
		}
		sorted(n, end)
		n = end + 1
	}
	for n := 1 << 19; n <= 1<<24; n <<= 1 {
		for _, m := range []int{n - 1, n, n + 1} {
			copied(m, m)
			sorted(m/16, m/16)
		}
	}
'''
if s.count(old) != 1:
    raise SystemExit('not found')
s = s.replace(old, new)
s = s.replace('''//   - a string's copy (copyBytes), for every length to 2^24 bytes, as the
//     meter replays it (stringCopy);
//   - the sorted names of a hashed object (namesBytes), for every member
//     count to 2^20 (pointerSlice);''', '''//   - a string's copy (copyBytes), for every length to 256 KiB, past which
//     whole pages round every length alike, and around every power of two
//     to 16 MiB, as the meter replays it (stringCopy);
//   - the sorted names of a hashed object (namesBytes), for every member
//     count to 16,384 and around powers of two past (pointerSlice);''')
open(p, 'w', encoding='utf-8', newline='\n').write(s)
print('ok')
