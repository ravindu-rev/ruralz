import sys, os
root = sys.argv[1]
p = os.path.join(root, 'working_test.go')
s = open(p, encoding='utf-8').read()
pairs = [
    ('''	const (
		at0, at1 = errorBytes, errorBytes + locationBytes
		e        = decideErrorBytes
		wrapper  = decideFrames*stackBytes + listGrowthBytes
	)''', '''	const (
		at0, at1 = errorBytes, errorBytes + locationBytes
		e        = decideErrorBytes
		wrapper  = decideFrames*stackBytes + listGrowthBytes
		// short is the copy of a string shorter than 16 bytes, which may
		// start a block of the allocator's tiny allocator (copyBytes).
		short = tinyBlockBytes
	)'''),
    ('''`"x"`, e, 2 * at0, stackBytes + wrapper, 1},
		{"required list"''', '''`"x"`, e, 2 * at0, stackBytes + wrapper, short},
		{"required list"'''),
    ('''`"x"`, e, at0, stackBytes + wrapper, 1},
		{"lengths that hold", `{"minLength":1,"maxLength":3}`, `"xyz"`, 0, 0, stackBytes + wrapper, 3},''', '''`"x"`, e, at0, stackBytes + wrapper, short},
		{"lengths that hold", `{"minLength":1,"maxLength":3}`, `"xyz"`, 0, 0, stackBytes + wrapper, short},'''),
    ('''`"xyz"`, 3 * e, 3 * at0, 2*stackBytes + wrapper, 3},
		{"lengths in characters", `{"maxLength":1}`, `"é"`, 0, 0, stackBytes + wrapper, 2},
		{"two failing lengths and a group", `{"minLength":2,"maxLength":0}`, `"x"`, 3 * e, 2 * at0, stackBytes + wrapper, 1},''', '''`"xyz"`, 3 * e, 3 * at0, 2*stackBytes + wrapper, short},
		{"lengths in characters", `{"maxLength":1}`, `"é"`, 0, 0, stackBytes + wrapper, short},
		{"two failing lengths and a group", `{"minLength":2,"maxLength":0}`, `"x"`, 3 * e, 2 * at0, stackBytes + wrapper, short},'''),
    ('''`"x"`, 2 * e, 2 * at0, 3*stackBytes + wrapper, 1},''', '''`"x"`, 2 * e, 2 * at0, 3*stackBytes + wrapper, short},'''),
    ('''`{"abcd":1}`, e + 2*at0, at1 + at0, 2*stackBytes + wrapper, 4},''', '''`{"abcd":1}`, e + 2*at0, at1 + at0, 2*stackBytes + wrapper, short},'''),
    ('''			3*e + (3+1)*at0, 3*at1 + at0 + 2*at0, 4*stackBytes + wrapper, 4,''', '''			3*e + (3+1)*at0, 3*at1 + at0 + 2*at0, 4*stackBytes + wrapper, short,'''),
]
for old, new in pairs:
    if s.count(old) != 1:
        raise SystemExit('%d matches for %s' % (s.count(old), old[:120]))
    s = s.replace(old, new)
open(p, 'w', encoding='utf-8', newline='\n').write(s)
print('ok')
