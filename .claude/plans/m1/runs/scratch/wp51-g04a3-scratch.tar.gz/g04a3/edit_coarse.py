import os
import sys

root = sys.argv[1]


def load(name):
    return open(os.path.join(root, name), encoding='utf-8').read()


def save(name, s):
    open(os.path.join(root, name), 'w', encoding='utf-8', newline='\n').write(s)


def rep1(s, old, new):
    if s.count(old) != 1:
        raise SystemExit('%d matches for %r' % (s.count(old), old[:100]))
    return s.replace(old, new)


def in_func(s, name, old, new):
    a = s.index('\nfunc ' + name + '(') + 1
    b = s.index('\n}\n', a) + 3
    return s[:a] + rep1(s[a:b], old, new) + s[b:]


s = load('meter_test.go')
s = rep1(s, '''	// only, when set, is the one position whose exit probe marks, at every
	// call, for the tests of a shape repeated along branches; the entry
	// probes then mark nothing, while the ends of the passes and the
	// matches still mark.
	only string''', '''	// only, when set, is the one position whose exit probe marks, at every
	// call, for the tests of a shape repeated along branches; the entry
	// probes then mark nothing, while the ends of the passes and the
	// matches still mark.
	only string
	// coarse, set by the tests of the measured fit, valid bodies whose
	// decoded values are most of the heap, marks a pass only at its first
	// entry probe, first exit probe and first match, at its root's exit and
	// its end, and at the matches metered past them: such a pass holds,
	// besides the values, the evaluations on the path to one value at a
	// time, whose copies are replayed whatever the schedule (review
	// finding: the full schedule's collections of heaps of 40 to 120 MB
	// took TestHandleMeasuredFit to 570 s on a loaded machine).
	coarse bool''')
s = rep1(s, '''func (m *heapMeter) dueProbe(n int) bool {
	m.probes++
	return due(m.probes, &m.nextProbe) || n <= probeHead
}''', '''func (m *heapMeter) dueProbe(n int) bool {
	m.probes++
	if m.coarse {
		return n == 1
	}
	return due(m.probes, &m.nextProbe) || n <= probeHead
}

// dueMatch counts a match of the pass and reports whether it marks the
// meter as due: the first under coarse, as the probes.
func (m *heapMeter) dueMatch() bool {
	m.matches++
	if m.coarse {
		return m.matches == 1
	}
	return due(m.matches, &m.nextMatch)
}''')
s = rep1(s, '''	m := p.m
	m.matches++
	jobs := -1''', '''	m := p.m
	metered := m.dueMatch()
	jobs := -1''')
s = rep1(s, '''	if most, seen := m.jobs[p]; !due(m.matches, &m.nextMatch) && jobs >= 0 && seen && jobs <= most {''', '''	if most, seen := m.jobs[p]; !metered && jobs >= 0 && seen && jobs <= most {''')
save('meter_test.go', s)

s = load('fit_test.go')
s = in_func(s, 'TestHandleMeasuredFit', '''			m := &heapMeter{}''', '''			m := &heapMeter{coarse: true}''')
save('fit_test.go', s)

s = load('work_limit_test.go')
s = in_func(s, 'TestHandleAcceptsLargeBodies', '''			m := &heapMeter{}''', '''			m := &heapMeter{coarse: true}''')
s = in_func(s, 'TestHandleReservesDecodedMaps', '''			m := &heapMeter{}''', '''			m := &heapMeter{coarse: true}''')
save('work_limit_test.go', s)

s = load('working_test.go')
s = in_func(s, 'TestPathStates', '''	m := &heapMeter{}''', '''	m := &heapMeter{coarse: true}''')
save('working_test.go', s)
print('ok')
