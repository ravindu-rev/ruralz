#!/bin/bash
# Class acceptance for GC-08: the memory-measuring tests at -test.count=$1,
# three processes per toolchain (go1.27.1 and go1.26.8 with jsonv2, both
# CGO_ENABLED=0) beside four busy loops. Binaries are built into the
# scratch directory; the tests run with the package directory as their
# working directory, as go test runs them.
set -u
COUNT=${1:-10}
S=/c/Users/ravin/AppData/Local/Temp/claude/c--Users-ravin-Projects-Ruralz/5104a226-9733-4230-8cf6-a5ff30e79ceb/scratchpad/wp51close/g04a3/stress
REPO=/c/Users/ravin/Projects/Ruralz
PKG=$REPO/internal/filter/validation/jsonschema
TESTS='^(TestWorkingSetCoversPeak|TestHandleUnevaluatedBranches|TestHandlePatternFit|TestHandleBacktrackCharge|TestHandleAcceptsLargeBodies|TestHandleBoundsMatchedItems|TestHandleBoundsUnevaluatedMemory|TestHandleBoundsValidationMemory|TestPathStates|TestHandleMeasuredFit|TestHandleReservesDecodedMaps|TestTinyBlocks|TestHeapMeter|TestDecisionTreeBesideCopies|TestDuplicatesReplica|TestGrowthCharges|TestCopySizes|TestNumberCheckMemory|TestHandleWalkMemory|TestStatesMemberPatterns)$'
mkdir -p $S
cd $REPO
GOTOOLCHAIN=go1.27.1 CGO_ENABLED=0 go test -c -o $S/new127.test.exe ./internal/filter/validation/jsonschema/ || exit 1
GOTOOLCHAIN=go1.26.8 GOEXPERIMENT=jsonv2 CGO_ENABLED=0 go test -c -o $S/new126.test.exe ./internal/filter/validation/jsonschema/ || exit 1
busy=()
for i in 1 2 3 4; do
	( while :; do :; done ) &
	busy+=($!)
done
start=$(date +%s)
pids=()
for bin in new127 new126; do
	for i in 1 2 3; do
		( cd $PKG && $S/$bin.test.exe -test.run "$TESTS" -test.count=$COUNT -test.timeout=600m > $S/$bin.$i.out 2>&1; echo "exit $?" >> $S/$bin.$i.out ) &
		pids+=($!)
	done
done
for p in "${pids[@]}"; do wait $p; done
kill "${busy[@]}" 2>/dev/null
end=$(date +%s)
echo "elapsed $((end-start)) s" > $S/summary.txt
for f in $S/new12*.out; do echo "$(basename $f): $(tail -1 $f) $(grep -c -- '--- FAIL' $f) FAIL lines" >> $S/summary.txt; done
cat $S/summary.txt
