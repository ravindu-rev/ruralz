import sys, os
root = sys.argv[1]


def edit(name, pairs):
    p = os.path.join(root, name)
    s = open(p, encoding='utf-8').read()
    for old, new in pairs:
        if s.count(old) != 1:
            raise SystemExit('%s: %d matches for %s' % (name, s.count(old), old[:120]))
        s = s.replace(old, new)
    open(p, 'w', encoding='utf-8', newline='\n').write(s)


edit('working.go', [
    ('''	// hashNameBytes is what hashing an object for uniqueItems holds per
	// member: the sorted slice of its names.
	hashNameBytes = 16''', '''	// hashNameBytes is what hashing an object for uniqueItems holds per
	// member: the sorted slice of its names, a string header each, with
	// the slice's rounding (namesBytes).
	hashNameBytes = 16'''),
    ('''		b.transient = max(b.transient, n)''', '''		b.transient = max(b.transient, copyBytes(n))'''),
    ('''		own = addCap(own, mulCap(n, hashNameBytes))''', '''		own = addCap(own, namesBytes(n))'''),
    ('''// arraySlotBytes is one item's slot in a decoded array's backing array,''', '''// copyBytes returns what the library's copy of a string of n bytes takes,
// which every evaluation at the string makes (validator.go strValidate):
// its allocation size, from 1 to 15 bytes at most the 16-byte block of
// the allocator's tiny allocator it may start (review finding, audit class
// GC-08: charged its bytes, the copy of a 100,000-byte string took 106,496
// and one of 32,769 bytes 40,960, TestCopySizes).
func copyBytes(n int64) int64 {
	switch {
	case n <= 0:
		return 0
	case n < tinyBlockBytes:
		return tinyBlockBytes
	}
	return n + stringExtra(n)
}

// mallocHeaderBytes is the header the allocator puts in front of an
// object holding pointers past 512 bytes (runtime mallocgc in Go 1.26 and
// 1.27).
const mallocHeaderBytes = 8

// namesBytes returns what hashing an object of n members for uniqueItems
// holds while it hashes them (util.go writeHash): the sorted slice of its
// names, hashNameBytes a name, rounded up to its allocation size with the
// header the allocator puts in front of a slice of pointers (review
// finding, audit class GC-08: charged its headers alone, the names of an
// object of 50,000 members took 802,824 bytes, charged 800,000,
// TestCopySizes).
func namesBytes(n int64) int64 {
	if n <= 0 {
		return 0
	}
	b := mulCap(n, hashNameBytes)
	if b > 512 {
		b = addCap(b, mallocHeaderBytes)
	}
	return addCap(b, stringExtra(b))
}

// arraySlotBytes is one item's slot in a decoded array's backing array,'''),
])

edit('meter_test.go', [
    ('''// mallocHeaderBytes is the header the allocator puts in front of an
// object holding pointers past 512 bytes, which append's capacities leave
// out (runtime mallocgc in Go 1.26 and 1.27).
const mallocHeaderBytes = 8

''', ''),
])
print('ok')
