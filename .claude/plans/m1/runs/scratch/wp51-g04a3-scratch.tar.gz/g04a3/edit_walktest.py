import sys, os
root = sys.argv[1]
p = os.path.join(root, 'working_test.go')
s = open(p, encoding='utf-8').read()
anchor = '// TestHandleLocationPass covers the two passes (proposed, 07 reqs 13, 18'
assert s.count(anchor) == 1
test = '''// TestHandleWalkMemory is the regression test of the review finding on
// the location walk (audit class GC-08): after the location pass, which
// no probe follows, the walk builds a pointer for each leaf of the error
// tree and keeps the best, which the model did not charge: a document
// whose failing keyword lies under a $defs name of 100,000 bytes held
// 300 KB in the walk of a body of one byte, which reserved 41 KB. The
// location pass is now charged the walk's pointers (walkBytes), at least
// four of the document's longest location, and Handle reserves them; the
// walk's pointers, replayed on the tree (walkCopy), are at least the one
// it builds and the best, within the reservation, and bound what the walk
// allocates.
//
// Requirements: 07 reqs 80 to 82 and architecture R-63.
func TestHandleWalkMemory(t *testing.T) {
	const n = 100000
	name := strings.Repeat("n", n)
	schema := `{"$ref":"#/$defs/` + name + `","$defs":{"` + name + `":{"type":"string","minLength":2}}}`
	f := buildFilter(t, schema, 0)
	_, scan := scanBody(t, f.schema, `1`)
	if walk := walkBytes(f.schema.work.flags.maxPointer); walk < 4*n || scan.locateMemory() < walk {
		t.Errorf("the location pass is charged %d bytes, its walk %d, want at least four pointers of %d bytes", scan.locateMemory(), walk, n)
	}
	m := &heapMeter{}
	r, reserved := handlePeak(t, f, schema, `1`, m)
	if got := detailOf(t, r); got != DetailMismatch+" at /$defs" {
		t.Fatalf("detail = %q, want the location cut back to /$defs", got)
	}
	requireMeter(t)
	var verr *sjs.ValidationError
	if !errors.As(f.schema.root.Validate(decodeInstance(t, `1`)), &verr) {
		t.Fatal("the body is valid")
	}
	var a, b runtime.MemStats
	gc := debug.SetGCPercent(-1)
	runtime.ReadMemStats(&a)
	_, _, _ = locationOf(verr, nil)
	runtime.ReadMemStats(&b)
	debug.SetGCPercent(gc)
	t.Logf("reserved %d, live peak %d, the walk replayed %d, allocated %d", reserved, m.peak(), m.copies[copyWalk], b.TotalAlloc-a.TotalAlloc)
	if walk := m.copies[copyWalk]; walk < 2*n || walk < int64(b.TotalAlloc-a.TotalAlloc) {
		t.Errorf("the walk replayed %d bytes, want the two pointers of %d bytes and its %d allocated", walk, n, b.TotalAlloc-a.TotalAlloc)
	}
	if exceeds(m.peak(), reserved) {
		t.Errorf("Handle held %d bytes at its peak, reserved %d", m.peak(), reserved)
	}
}

'''
s = s.replace(anchor, test + anchor)
open(p, 'w', encoding='utf-8', newline='\n').write(s)
print('ok')
