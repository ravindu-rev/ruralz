import sys, os
root = sys.argv[1]
p = os.path.join(root, 'working_test.go')
s = open(p, encoding='utf-8').read()
old = '''	requireMeter(t)
	sizes := func(upTo, past int) []int {
		var ns []int
		for n := 1; n <= upTo; n++ {
			ns = append(ns, n)
		}
		for n := 1 << 12; n <= past; n <<= 1 {
			ns = append(ns, n-1, n, n+1)
		}
		return ns
	}
	for _, n := range sizes(70000, 1<<24) {
		if got, charged := stringCopy(n), copyBytes(int64(n)); got > charged {
			t.Fatalf("the copy of %d bytes takes %d, charged %d", n, got, charged)
		}
	}
	for _, n := range sizes(5000, 1<<20) {
		if got, charged := pointerSlice(n, 16), namesBytes(int64(n)); got > charged {
			t.Fatalf("the sorted names of %d members take %d, charged %d", n, got, charged)
		}
	}
'''
new = '''	requireMeter(t)
	// Every length of a size class, or of a run of whole pages, takes the
	// allocation of its largest: replayed once per class.
	for n := 1; n <= 1<<24; {
		got, end := stringCopy(n), tinyBlockBytes-1
		if n >= tinyBlockBytes {
			end = int(got)
		}
		for m := n; m <= end; m++ {
			if charged := copyBytes(int64(m)); got > charged {
				t.Fatalf("the copy of %d bytes takes %d, charged %d", m, got, charged)
			}
		}
		n = end + 1
	}
	for n := 1; n <= 1<<20; {
		got := pointerSlice(n, 16)
		end := int(got / 16)
		if got > 512 {
			end = int((got - mallocHeaderBytes) / 16)
		}
		for m := n; m <= end; m++ {
			if charged := namesBytes(int64(m)); got > charged {
				t.Fatalf("the sorted names of %d members take %d, charged %d", m, got, charged)
			}
		}
		n = end + 1
	}
'''
if s.count(old) != 1:
    raise SystemExit('not found')
s = s.replace(old, new)
s = s.replace('''//   - a string's copy (copyBytes), for every length to 70,000 bytes and
//     around every power of two to 2^24, as the meter replays it
//     (stringCopy);
//   - the sorted names of a hashed object (namesBytes), for every member
//     count to 5,000 and around every power of two to 2^20 (pointerSlice);''', '''//   - a string's copy (copyBytes), for every length to 2^24 bytes, as the
//     meter replays it (stringCopy);
//   - the sorted names of a hashed object (namesBytes), for every member
//     count to 2^20 (pointerSlice);''')
open(p, 'w', encoding='utf-8', newline='\n').write(s)
print('ok')
