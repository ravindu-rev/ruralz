import sys, os
root = sys.argv[1]


def edit(name, pairs):
    p = os.path.join(root, name)
    s = open(p, encoding='utf-8').read()
    for old, new in pairs:
        if s.count(old) != 1:
            raise SystemExit('%s: %d matches for %s' % (name, s.count(old), old[:120]))
        s = s.replace(old, new)
    open(p, 'w', encoding='utf-8', newline='\n').write(s)


edit('meter_test.go', [
    ('''// format, an annotation in the package's compile), true becoming an
// object of the two probes, which the library evaluates as it evaluates
// true (compiler.go:246-259 gives both the same evaluated items and
// members), but where additionalProperties or additionalItems hold it,
// which the library keeps as a flag and evaluates no schema for; false
// stays, holding its one error and running nothing. With matchers set,
// every pattern matches through a meteredPattern. The compile's Schema is
// not used: its model is the one the measured figures are compared with.''', '''// format, an annotation in the package's compile), true becoming an
// object of the two probes, which the library evaluates as it evaluates
// true (compiler.go:246-259 gives both the same evaluated items and
// members), but where additionalProperties or additionalItems hold it,
// which the library keeps as a flag and evaluates no schema for; false
// stays, holding its one error and running nothing (an object failing in
// its place would change the error's keyword and so the location the
// pass reports). An object of probes copies a string and loops over an
// object's members where true does neither: garbage, which no mark
// counts, and its site replays no copy (trivial). With matchers set,
// every pattern matches through a meteredPattern. The compile's Schema is
// not used: its model is the one the measured figures are compared with.'''),
    ('''// locateProbe is the location pass of a probed compile: a reference to
// the document, whose error wraps the document's errors and whose
// x-probe-end, which the location pass reaches at every evaluation, marks
// the end of the pass with the whole error tree live, also when the
// document fails before any probe of its own runs. The wrapping error has
// causes, so the location walk visits the document's leaves alone and
// reports what the document's root reports (leaves).''', '''// locateProbe is the location pass of a probed compile: a reference to
// the document, whose error wraps the document's errors and whose
// x-probe-end, which the location pass reaches at every evaluation, marks
// the end of the pass with the whole error tree live, also when the
// document fails before any probe of its own runs. The wrapping error has
// causes, so the location walk visits the document's leaves alone and
// reports what the document's root reports (leaves). The wrapper's own
// evaluation and error, a few hundred bytes, count in the pass's figures,
// which only adds to them.'''),
])
print('ok')
