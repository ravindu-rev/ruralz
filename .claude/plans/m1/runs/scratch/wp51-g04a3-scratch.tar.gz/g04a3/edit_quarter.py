import os
import sys

root = sys.argv[1]


def edit(name, pairs):
    p = os.path.join(root, name)
    s = open(p, encoding='utf-8').read()
    for old, new in pairs:
        if s.count(old) != 1:
            raise SystemExit('%s: %d matches for %r' % (name, s.count(old), old[:100]))
        s = s.replace(old, new)
    open(p, 'w', encoding='utf-8', newline='\n').write(s)


edit('meter_test.go', [
    ('''// largest. Each pass marks at its first entry probes, exit probes and
// matches, then at those spread over the rest of it however long it is
// (due), or, coarse, at the first of each alone, at every exit probe at
// the document's root and at the end of the pass. The copies the library
// makes between two marks are replayed (copies), the largest added to the
// largest mark (peak).''', '''// largest. Each pass marks at its first entry probes, exit probes and
// matches, then at those spread over the rest of it however long it is
// (due), at every exit probe at the document's root and at the end of the
// pass. The copies the library makes between two marks are replayed
// (copies), the largest added to the largest mark (peak).'''),
    ('''	only string
	// coarse, set by the tests of the measured fit, valid bodies whose
	// decoded values are most of the heap, marks a pass only at its first
	// entry probe, first exit probe and first match, at its root's exit and
	// its end, and at the matches metered past them: such a pass holds,
	// besides the values, the evaluations on the path to one value at a
	// time, whose copies are replayed whatever the schedule (review
	// finding: the full schedule's collections of heaps of 40 to 120 MB
	// took TestHandleMeasuredFit to 570 s on a loaded machine).
	coarse bool
''', '''	only string
'''),
    ('''// probeHead is how many entry probes, exit probes and matches of a pass
// each mark the meter first, and probeGrowth sets the marks past them: one
// each time the pass's count of probes of both kinds, or of matches, has
// grown by half since the last (due, dueProbe). The first entry probes of
// a pass descend its first path and its first exit probes are the deepest
// evaluations there, while the unevaluated copies and the errors of every
// evaluation above them are live; the marks past them follow the pass to
// its end, so that the error tree a failing body's pass grows over its
// values is measured where it is largest (a schema's extension keywords
// run after its applicators failed, in either pass, validator.go
// validate), and the last falls in its last third, before the end mark.
// Each mark collects the heap twice, so the marks of a pass grow with the
// logarithm of its probes (review finding: marks every quarter in both
// kinds of probe took the package's suites without -race past go test's
// default 10-minute timeout beside two other suites on a loaded machine).
// The goroutine's stack is not heap: TestStackWithinCharge measures it.
const probeHead, probeGrowth = 4, 2''', '''// probeHead is how many entry probes, exit probes and matches of a pass
// each mark the meter first, and probeGrowth sets the marks past them: one
// each time the pass's count of probes of both kinds, or of matches, has
// grown by a quarter since the last (due, dueProbe). The first entry
// probes of a pass descend its first path and its first exit probes are
// the deepest evaluations there, while the unevaluated copies and the
// errors of every evaluation above them are live; the marks past them
// follow the pass to its end, so that the error tree a failing body's pass
// grows over its values is measured where it is largest (a schema's
// extension keywords run after its applicators failed, in either pass,
// validator.go validate), and the last falls in its last fifth, before the
// end mark. Each mark collects the heap twice, so the marks of a pass
// grow with the logarithm of its probes alone. The goroutine's stack is
// not heap: TestStackWithinCharge measures it.
const probeHead, probeGrowth = 8, 4'''),
    ('''// due reports whether the n-th probe call or match of a pass marks the
// meter: one of the first probeHead, or the one at which the count has
// grown by half since the last mark past them, *next holding that count
// (0 at the start of a pass).''', '''// due reports whether the n-th probe call or match of a pass marks the
// meter: one of the first probeHead, or the one at which the count has
// grown by a quarter since the last mark past them, *next holding that
// count (0 at the start of a pass).'''),
    ('''func (m *heapMeter) dueProbe(n int) bool {
	m.probes++
	if m.coarse {
		return n == 1
	}
	return due(m.probes, &m.nextProbe) || n <= probeHead
}

// dueMatch counts a match of the pass and reports whether it marks the
// meter as due: the first under coarse, as the probes.
func (m *heapMeter) dueMatch() bool {
	m.matches++
	if m.coarse {
		return m.matches == 1
	}
	return due(m.matches, &m.nextMatch)
}''', '''func (m *heapMeter) dueProbe(n int) bool {
	m.probes++
	return due(m.probes, &m.nextProbe) || n <= probeHead
}

// dueMatch counts a match of the pass and reports whether it marks the
// meter as due.
func (m *heapMeter) dueMatch() bool {
	m.matches++
	return due(m.matches, &m.nextMatch)
}'''),
    ('''//   - due marks the first probeHead counts of a pass, then each count that
//     has grown by half since the last mark, so the last falls in the
//     pass's last third.''', '''//   - due marks the first probeHead counts of a pass, then each count that
//     has grown by a quarter since the last mark, so the last falls in the
//     pass's last fifth.'''),
    ('''//     entry probes, exit probes and matches and those spread over it, and
//     each ends at its end probe; coarse, a valid body's pass marks its
//     first entry probe, exit probe and match and its root's exit alone.''', '''//     entry probes, exit probes and matches and those spread over it, and
//     each ends at its end probe.'''),
    ('''//     there, is measured with at least two thirds of the list live, also''', '''//     there, is measured with at least four fifths of the list live, also'''),
    ('''		want := []int{1, 2, 3, 4, 5, 7, 10, 15, 22, 33, 49, 73}''', '''		want := []int{1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 13, 16, 20, 25, 31, 38, 47, 58, 72, 90}'''),
    ('''			if 3*last < 2*total {
				t.Errorf("of %d counts the last marked is %d, before the last third", total, last)
			}''', '''			if 5*last < 4*total {
				t.Errorf("of %d counts the last marked is %d, before the last fifth", total, last)
			}'''),
    ('''		// Each pass: 21 entry probes (the root and its 20 items); the
		// decision pass, failing at every item, no exit probe, so 8 of its
		// 21 probes due; the location pass 21 exit probes too, the first 4
		// of each kind and those due among its 42 probes marking, 6 and 7
		// with the root's exit; 20 matches, of which 8 due, the
		// backtracker's job stack being the same at each.
		if got := fmt.Sprint(m.byPass); m.ends != 2 || got != "[{8 0 8} {6 7 8} {0 0 0}]" || len(m.at[endMark]) != 2 {
			t.Errorf("the passes marked %s, ended %d times, %d end marks; want [{8 0 8} {6 7 8} {0 0 0}], twice and twice", got, m.ends, len(m.at[endMark]))
		}''', '''		// Each pass: 21 entry probes (the root and its 20 items); the
		// decision pass, failing at every item, no exit probe, so 13 of its
		// 21 probes due; the location pass 21 exit probes too, the first 8
		// of each kind and those due among its 42 probes marking, 11 and 11
		// with the root's exit; 20 matches, of which 13 due, the
		// backtracker's job stack being the same at each.
		if got := fmt.Sprint(m.byPass); m.ends != 2 || got != "[{13 0 13} {11 11 13} {0 0 0}]" || len(m.at[endMark]) != 2 {
			t.Errorf("the passes marked %s, ended %d times, %d end marks; want [{13 0 13} {11 11 13} {0 0 0}], twice and twice", got, m.ends, len(m.at[endMark]))
		}'''),
    ('''	t.Run("coarse", func(t *testing.T) {
		// A valid body's one pass: its first entry probe, its first exit
		// probe and its root's, and its first match.
		schema := `{"type":"array","items":{"type":"string","pattern":"^a"}}`
		m := &heapMeter{coarse: true}
		if r, _ := handlePeak(t, buildFilter(t, schema, 0), schema, denseArray(20, `"a"`, 0), m); r.Outcome != filter.Continue {
			t.Fatalf("Handle = %+v, want Continue", r)
		}
		if got := fmt.Sprint(m.byPass); m.ends != 0 || got != "[{1 2 1}]" {
			t.Errorf("the pass marked %s, ended %d times at an end probe; want [{1 2 1}], never", got, m.ends)
		}
	})
''', ''),
    ('''			if list := int64(items * 8 * 2 / 3); at < list-heapNoise {
				t.Errorf("%s: the probes in the contains loop measured at most %d bytes, want at least two thirds of the list, %d", schema, at, list)''', '''			if list := int64(items * 8 * 4 / 5); at < list-heapNoise {
				t.Errorf("%s: the probes in the contains loop measured at most %d bytes, want at least four fifths of the list, %d", schema, at, list)'''),
    ('''		// The 9 due, the 22nd the last of them, and the 30th.
		if m.matcher < int64(16*jobs) || m.byPass[0].matches != 10 {
			t.Errorf("the matcher's peak measured %d bytes in %d metered matches, want its %d jobs measured at the 30th, 10 metered", m.matcher, m.byPass[0].matches, jobs)
		}''', '''		// The 14 due, the 25th the last of them, and the 30th.
		if m.matcher < int64(16*jobs) || m.byPass[0].matches != 15 {
			t.Errorf("the matcher's peak measured %d bytes in %d metered matches, want its %d jobs measured at the 30th, 15 metered", m.matcher, m.byPass[0].matches, jobs)
		}'''),
])

edit('working_test.go', [
    ('''	// items of the chain's contains, which is true, two thirds of one list''', '''	// items of the chain's contains, which is true, four fifths of one list'''),
    ('''	holds := map[string]int64{"matching items along a chain": 16000 * 8 * 2 / 3}''', '''	holds := map[string]int64{"matching items along a chain": 16000 * 8 * 4 / 5}'''),
    ('''	m := &heapMeter{coarse: true}''', '''	m := &heapMeter{}'''),
])

edit('fit_test.go', [
    ('''			m := &heapMeter{coarse: true}''', '''			m := &heapMeter{}'''),
])

p = os.path.join(root, 'work_limit_test.go')
s = open(p, encoding='utf-8').read()
if s.count('m := &heapMeter{coarse: true}') != 2:
    raise SystemExit('work_limit_test.go: want 2 coarse meters')
s = s.replace('m := &heapMeter{coarse: true}', 'm := &heapMeter{}')
open(p, 'w', encoding='utf-8', newline='\n').write(s)
print('ok')
