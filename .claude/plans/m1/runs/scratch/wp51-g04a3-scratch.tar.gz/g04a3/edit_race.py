import os
import re
import sys

root = sys.argv[1]


def load(name):
    return open(os.path.join(root, name), encoding='utf-8').read()


def save(name, s):
    open(os.path.join(root, name), 'w', encoding='utf-8', newline='\n').write(s)


def func_span(s, name):
    a = s.index('\nfunc ' + name + '(') + 1
    b = s.index('\n}\n', a) + 3
    return a, b


def edit_func(s, name, fn):
    a, b = func_span(s, name)
    return s[:a] + fn(s[a:b]) + s[b:]


def rep1(text, old, new):
    if text.count(old) != 1:
        raise SystemExit('%d matches for %r' % (text.count(old), old[:100]))
    return text.replace(old, new)


def drop_scale(body):
    body = re.sub(r'\(([0-9]+(?:<<[0-9]+)?) ?/ ?scale\)', r'(\1)', body)
    body = re.sub(r'([0-9]+(?:<<[0-9]+)?) ?/ ?scale', r'\1', body)
    if 'scale' in body.replace('Scale', ''):
        for line in body.split('\n'):
            if 'scale' in line:
                print('left:', line.strip()[:120])
    return body


# fit_test.go
s = load('fit_test.go')


def fit(body):
    body = rep1(body, '''	// The fractions do not depend on the limit: under -race, which slows
	// the library tenfold, a tenth of the default limit and of the bodies,
	// and a tree nested two levels less (about a tenth of the bytes and
	// of the working set).
	limit, scale, raw, depth := int64(10<<20), 1, int64(0), 6
	if raceEnabled {
		limit, scale, raw, depth = 1<<20, 10, 1<<20, 4
	}
''', '''	requireMeter(t)
	// The fractions are of the 10 MiB default.
	const limit = 10 << 20
''')
    body = rep1(body, '''	// Distinct prices of the same length whatever the scale.''', '''	// Distinct prices of the same length.''')
    body = rep1(body, '''{"component tree nested deep", componentTree, uiTree(depth, 3, true), 0},''', '''{"component tree nested deep", componentTree, uiTree(6, 3, true), 0},''')
    body = rep1(body, '''			f := buildFilter(t, tc.schema, raw)''', '''			f := buildFilter(t, tc.schema, 0)''')
    body = rep1(body, '''			requireMeter(t)
			peak := m.peak()''', '''			peak := m.peak()''')
    return drop_scale(body)


s = edit_func(s, 'TestHandleMeasuredFit', fit)
s = rep1(s, '''// reservation against that peak. Under -race, which measures nothing, it checks
// the outcome and the reservation alone. The decision pass is reserved its''', '''// reservation against that peak. The decision pass is reserved its''')


def pattern_fit(body):
    body = rep1(body, '''func TestHandlePatternFit(t *testing.T) {
''', '''func TestHandlePatternFit(t *testing.T) {
	requireMeter(t)
''')
    body = rep1(body, '''			requireMeter(t)
			t.Logf("%d bytes: reserved''', '''			t.Logf("%d bytes: reserved''')
    return body


s = edit_func(s, 'TestHandlePatternFit', pattern_fit)
save('fit_test.go', s)

# regexcost_test.go
s = load('regexcost_test.go')


def backtrack(body):
    body = rep1(body, '''func TestHandleBacktrackCharge(t *testing.T) {
''', '''func TestHandleBacktrackCharge(t *testing.T) {
	requireMeter(t)
''')
    body = rep1(body, '''			requireMeter(t)
			t.Logf("reserved %d, live peak''', '''			t.Logf("reserved %d, live peak''')
    return body


s = edit_func(s, 'TestHandleBacktrackCharge', backtrack)
save('regexcost_test.go', s)

# work_limit_test.go
s = load('work_limit_test.go')


def accepts(body):
    body = rep1(body, '''	// The fractions do not depend on the limit: under -race, which slows
	// the library tenfold, a tenth of the default limit and of the bodies.
	limit, scale, raw := int64(10<<20), 1, int64(0)
	if raceEnabled {
		limit, scale, raw = 1<<20, 10, 1<<20
	}
''', '''	// The fractions are of the 10 MiB default.
	const limit = 10 << 20
''')
    body = rep1(body, '''func TestHandleAcceptsLargeBodies(t *testing.T) {
''', '''func TestHandleAcceptsLargeBodies(t *testing.T) {
	requireMeter(t)
''')
    body = rep1(body, '''			f := buildFilter(t, tc.schema, raw)''', '''			f := buildFilter(t, tc.schema, 0)''')
    body = rep1(body, '''			requireMeter(t)
			peak := m.peak()''', '''			peak := m.peak()''')
    return drop_scale(body)


s = edit_func(s, 'TestHandleAcceptsLargeBodies', accepts)


def reserves(body):
    body = rep1(body, '''	limit, scale, raw := int64(10<<20), 1, int64(0)
	if raceEnabled {
		limit, scale, raw = 1<<19, 20, 1<<19
	}
''', '''	requireMeter(t)
	// The fractions are of the 10 MiB default.
	const limit = 10 << 20
''')
    body = rep1(body, '''			f := buildFilter(t, tc.schema, raw)''', '''			f := buildFilter(t, tc.schema, 0)''')
    body = rep1(body, '''			requireMeter(t)
			base := liveHeap()''', '''			base := liveHeap()''')
    return drop_scale(body)


s = edit_func(s, 'TestHandleReservesDecodedMaps', reserves)
save('work_limit_test.go', s)

# working_test.go
s = load('working_test.go')


def at_start(name, middle_old, middle_new):
    def fn(body):
        body = rep1(body, 'func ' + name + '(t *testing.T) {\n', 'func ' + name + '(t *testing.T) {\n\trequireMeter(t)\n')
        if middle_old:
            body = rep1(body, middle_old, middle_new)
        return body
    return fn


s = edit_func(s, 'TestHandleBoundsUnevaluatedMemory', at_start('TestHandleBoundsUnevaluatedMemory', '''	requireMeter(t)
	// The deepest link, the first exit probe''', '''	// The deepest link, the first exit probe'''))
s = edit_func(s, 'TestHandleUnevaluatedBranches', at_start('TestHandleUnevaluatedBranches', '''			requireMeter(t)
			deepest := m.at["/$defs/c3"]''', '''			deepest := m.at["/$defs/c3"]'''))
s = edit_func(s, 'TestHandleBoundsMatchedItems', at_start('TestHandleBoundsMatchedItems', '''	n := 16000
	if raceEnabled {
		n /= 4
	}
''', '''	const n = 16000
'''))
s = edit_func(s, 'TestHandleBoundsMatchedItems', lambda body: rep1(body, '''	requireMeter(t)
	// The location pass ends at the root''', '''	// The location pass ends at the root'''))
s = edit_func(s, 'TestHandleBoundsValidationMemory', at_start('TestHandleBoundsValidationMemory', '''	requireMeter(t)
	t.Logf("live peak %d, reserved''', '''	t.Logf("live peak %d, reserved'''))
s = edit_func(s, 'TestPathStates', at_start('TestPathStates', '''	requireMeter(t)
	t.Logf("body %d bytes: reserved''', '''	t.Logf("body %d bytes: reserved'''))
s = edit_func(s, 'TestHandleWalkMemory', at_start('TestHandleWalkMemory', '''	requireMeter(t)
	var verr *sjs.ValidationError''', '''	var verr *sjs.ValidationError'''))
save('working_test.go', s)

# patternsize_test.go: a live-heap measurement too.
s = load('patternsize_test.go')
s = edit_func(s, 'TestPatternProgramMemory', lambda body: rep1(body, 'func TestPatternProgramMemory(t *testing.T) {\n', 'func TestPatternProgramMemory(t *testing.T) {\n\trequireMeter(t)\n'))
save('patternsize_test.go', s)

# meter_test.go: handlePeak always measures.
s = load('meter_test.go')
s = rep1(s, '''	x, _ := exchange("application/json", []byte(body))
	var r filter.Result
	var reserved int64
	if raceEnabled {
		px := &peakExchange{Exchange: x}
		r, reserved = f.Handle(t.Context(), phase.OnRequestBody, px), px.peak
	} else {
		pf := probedFilter(t, f, schema, m)
		mx := &meterExchange{Exchange: x, m: m}
		m.start()
		r, reserved = pf.Handle(t.Context(), phase.OnRequestBody, mx), mx.peak
		m.check(t)
		// The location pass ran: its walk's pointers, replayed on the
		// tree of f's own location pass.
		if m.ends == 2 {
			v, _, err := f.decode([]byte(body))
			if err != nil {
				t.Fatal(err)
			}
			var verr *sjs.ValidationError
			if errors.As(f.schema.root.Validate(v), &verr) {
				m.copy(copyWalk, walkCopy(verr))
			}
		}
	}
	if x.Budget.Reserved != 0 {
		t.Errorf("reservation left: %d", x.Budget.Reserved)
	}
	return r, reserved
}''', '''	x, _ := exchange("application/json", []byte(body))
	pf := probedFilter(t, f, schema, m)
	mx := &meterExchange{Exchange: x, m: m}
	m.start()
	r := pf.Handle(t.Context(), phase.OnRequestBody, mx)
	m.check(t)
	if x.Budget.Reserved != 0 {
		t.Errorf("reservation left: %d", x.Budget.Reserved)
	}
	// The location pass ran: its walk's pointers, replayed on the tree of
	// f's own location pass.
	if m.ends == 2 {
		v, _, err := f.decode([]byte(body))
		if err != nil {
			t.Fatal(err)
		}
		var verr *sjs.ValidationError
		if errors.As(f.schema.root.Validate(v), &verr) {
			m.copy(copyWalk, walkCopy(verr))
		}
	}
	return r, mx.peak
}''')
s = rep1(s, '''// passes made, and the location walk's pointers, on top. Under -race it
// runs f itself and measures nothing (requireMeter).''', '''// passes made, and the location walk's pointers, on top.''')
s = rep1(s, '''// The race detector changes what the library allocates (it gives every
// small allocation a block of its own) and slows every collection, so the
// tests measure nothing under -race (requireMeter): there they check what
// Handle decides and reserves alone (review finding: the meter's
// collections took the package's race run past go test's default
// 10-minute timeout on a loaded 4-CPU machine).''', '''// The race detector changes what the library allocates (it gives every
// small allocation a block of its own) and slows every collection, and
// these tests run one goroutine, so the tests that measure memory skip
// under -race (requireMeter), as TestStackWithinCharge does, and run in
// the suites without it (review finding: the meter's collections took the
// package's race run past go test's default 10-minute timeout on a loaded
// 4-CPU machine).''')
s = rep1(s, '''// requireMeter skips the rest of a test under -race, which measures
// nothing (see the class comment above).''', '''// requireMeter skips a test that measures memory under -race (see the
// class comment above).''')
save('meter_test.go', s)
print('ok')
