import sys, os
root = sys.argv[1]


def edit(name, pairs):
    p = os.path.join(root, name)
    s = open(p, encoding='utf-8').read()
    for old, new in pairs:
        if s.count(old) != 1:
            raise SystemExit('%s: %d matches for %s' % (name, s.count(old), old[:120]))
        s = s.replace(old, new)
    open(p, 'w', encoding='utf-8', newline='\n').write(s)


edit('meter_test.go', [
    ('''// direction. The tests measure the live heap instead, and replay what the
// library holds between two measurements:
//
//   - a heapMeter mark collects the heap fully and reads the bytes still
//     reachable, which depend on the code path, not on the collector's
//     pacing, so a figure holds no garbage;
//   - the marks are taken where the library calls the test's code: at the
//     start of every evaluation that passes its type, const and enum (the
//     entry probe, an asserted format), at the end of every evaluation that
//     reaches its extension keywords (the exit probe, x-probe), at the end
//     of each pass (x-probe-end), at a reservation and at a regexp match;
//   - what the library allocates and drops within one evaluation's own
//     keywords, where it calls no code of the test, is replayed from the
//     evaluation's schema and value (copies): the copy of a string, the
//     uniqueItems duplicates map with the names it sorts and the number it
//     parses, the names additionalProperties false lists, the errors a
//     contains loop over false drops, a number check's rationals and a
//     matcher's own peak (review finding: the duplicates map of a valid
//     uniqueItems array, about 58 bytes per item, and the lists of every
//     loop under a true subschema were never measured, while the sampled
//     heap had counted them), and it is added once to the largest live
//     heap a mark measured, as the model adds its transient copy once to a
//     pass's tree and path;
//   - a list or a map the library grows holds its old array or table
//     besides the new one while it grows, which the marks never see
//     either: TestGrowthCharges replays that growth against the model's
//     charge per item;
//   - what the runtime itself allocates meanwhile and keeps is not garbage
//     either, and it does depend on the machine's load: heapNoise bounds
//     it, and every comparison of a measured figure with a charge allows it
//     (exceeds), or allows treeSlack, which is larger.''', '''// direction. The tests measure the live heap instead, and replay what the
// library holds between two measurements:
//
//   - a heapMeter mark collects the heap fully and reads the bytes still
//     reachable, which depend on the code path, not on the collector's
//     pacing, so a figure holds no garbage;
//   - the marks are taken where the library calls the test's code, as the
//     meter schedules them: at the start of an evaluation that passes its
//     type, const and enum (the entry probe, an asserted format), at the
//     end of one that reaches its extension keywords (the exit probe,
//     x-probe), at the end of each pass (x-probe-end), at a reservation and
//     at a regexp match, whose matcher's own peak is computed from what the
//     match allocated (matcherPeak);
//   - what the library allocates and drops within one evaluation's own
//     keywords, where it calls no code of the test, is replayed from the
//     evaluation's schema and value (copies): a string's copy, the
//     uniqueItems duplicates map with the names it sorts, the names
//     additionalProperties false lists and the errors a contains loop over
//     false drops, and a number check's rationals are bounded
//     (numberCheckBytes; review finding: the duplicates map of a valid
//     uniqueItems array, about 58 bytes per item, and every copy and list
//     in an evaluation of true or in one that fails before its exit probe
//     were never measured, while the sampled heap had counted them). The
//     largest of them or of the matchers is added once to the largest live
//     heap a mark measured, as the model adds its transient copy once to a
//     pass's tree and path (peak);
//   - a list or a map the library grows holds its old array or table
//     besides the new one while it grows, which the marks never see
//     either: TestGrowthCharges replays that growth against the model's
//     charge per item;
//   - what the runtime itself allocates meanwhile and keeps is not garbage
//     either, and it does depend on the machine's load: heapNoise bounds
//     it, and every comparison of a measured figure with a charge allows it
//     (exceeds), or allows treeSlack, which is larger. The meter's own
//     records, its marks and its replays' cache, a few kilobytes, count in
//     its figures too, which only adds to them.'''),
    ('''	// jobs holds the most jobs of the backtracker at a metered match of
	// each pattern in the measurement; sizes and duplicates cache the
	// allocation sizes and the duplicates copies replayed.
	jobs       map[*meteredPattern]int
	sizes      map[int]int64
	duplicates map[uintptr]int64''', '''	// jobs holds the most jobs of the backtracker at a metered match of
	// each pattern in the measurement, and duplicates caches the
	// duplicates copies replayed, by array.
	jobs       map[*meteredPattern]int
	duplicates map[uintptr]int64'''),
    ('''	m.jobs = map[*meteredPattern]int{}
	if m.sizes == nil {
		m.sizes, m.duplicates = map[int]int64{}, map[uintptr]int64{}
	}''', '''	m.jobs = map[*meteredPattern]int{}
	if m.duplicates == nil {
		m.duplicates = map[uintptr]int64{}
	}'''),
    ('''		m.copy(copyString, m.stringCopy(len(v)))''', '''		m.copy(copyString, stringCopy(len(v)))'''),
    ('''// stringCopy returns what the library's copy of a string of n bytes
// takes: none for an empty string, a share of a 16-byte tiny block, at
// most the block, below 16 bytes, and the allocation size of the bytes
// past them, as append rounds a byte slice up (a string's copy and a byte
// slice's growth both round with runtime roundupsize).
func (m *heapMeter) stringCopy(n int) int64 {
	switch {
	case n == 0:
		return 0
	case n < tinyBlockBytes:
		return tinyBlockBytes
	}
	if size, ok := m.sizes[n]; ok {
		return size
	}
	size := int64(cap(append([]byte(nil), make([]byte, n)...)))
	m.sizes[n] = size
	return size
}''', '''// stringCopy returns what the library's copy of a string of n bytes
// takes: none for an empty string, a share of a 16-byte tiny block, at
// most the block, below 16 bytes, and the allocation size of the bytes
// past them, as append rounds a byte slice up (a string's copy and a byte
// slice's growth both round with runtime roundupsize).
func stringCopy(n int) int64 {
	switch {
	case n == 0:
		return 0
	case n < tinyBlockBytes:
		return tinyBlockBytes
	}
	return int64(cap(append([]byte(nil), make([]byte, n)...)))
}'''),
    ('''	case json.Number:
		b.WriteByte(5)
		r, _ := new(big.Rat).SetString(string(t))
		b.Write(r.Num().Bytes())
		b.Write(r.Denom().Bytes())
	}''', '''	case json.Number:
		b.WriteByte(5)
		if r, ok := new(big.Rat).SetString(string(t)); ok {
			b.Write(r.Num().Bytes())
			b.Write(r.Denom().Bytes())
		}
	}'''),
    ('''	case json.Number:
		r, _ := new(big.Rat).SetString(string(t))
		return "#" + r.RatString()''', '''	case json.Number:
		if r, ok := new(big.Rat).SetString(string(t)); ok {
			return "#" + r.RatString()
		}'''),
])
print('ok')
