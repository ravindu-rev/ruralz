import sys, os
root = sys.argv[1]


def edit(name, pairs):
    p = os.path.join(root, name)
    s = open(p, encoding='utf-8').read()
    for old, new in pairs:
        if s.count(old) != 1:
            raise SystemExit('%s: %d matches for %s' % (name, s.count(old), old[:120]))
        s = s.replace(old, new)
    open(p, 'w', encoding='utf-8', newline='\n').write(s)


edit('work_limit_test.go', [
    ('''// valid body reserves the decoded values, with the bytes their maps, arrays
// and strings hold beyond the decoder's charge
// (TestHandleReservesDecodedMaps), and the decision pass's working set,
// never the location pass's, and at most two and a half times the live heap
// at Handle's peak, measured at the reservation and at the probes and
// matches heapMeter spreads over the decision pass to its end (audit class
// GC-08; the sampled heap in use it replaces counted the garbage of the
// decode and of validation), four and a half times for the enum values, each
// of which the decision pass is charged an error it may hold, 104 bytes
// against its 7; work is never reserved.''', '''// valid body reserves the decoded values, with the bytes their maps, arrays
// and strings hold beyond the decoder's charge
// (TestHandleReservesDecodedMaps), and the decision pass's working set,
// never the location pass's, which covers the live heap at Handle's peak,
// but for heapNoise, and is at most two and a half times it, four and a
// half times for the enum values, each of which the decision pass is
// charged an error it may hold, 104 bytes against its 7; work is never
// reserved. The peak is measured at the reservation and in the decision
// pass as heapMeter schedules it, with the largest copy the pass makes
// between two marks on top (audit class GC-08: the sampled heap in use
// this replaces counted the garbage of the decode and of validation; then
// the copy of a long string, as large as the string, which no probe saw,
// was left out, so a long string's body held twice what the reservation
// was then compared with, which charges it as the pass's transient copy).'''),
    ('''// reserved (07 req 82, architecture R-63, filter.Exchange.Reserve). The
// reservation now covers the decoded tree, measured after a collection, and
// the live heap at Handle's peak, measured at the reservation and at the
// probes of the decision pass, both but for heapNoise (heapMeter, audit
// class GC-08: the sampled heap in use this replaces counted the tables a
// wide object's map outgrew and the arrays the decoder outgrew, garbage
// before anything is reserved, and reached 1.41 times the reservation under
// load); strings are charged their allocation size class, or below 16 bytes
// their share of the allocator's blocks (TestTinyBlocks).''', '''// reserved (07 req 82, architecture R-63, filter.Exchange.Reserve). The
// reservation now covers the decoded tree, measured after a collection, and
// the live heap at Handle's peak, measured at the reservation and in the
// decision pass as heapMeter schedules it, with the copies the pass makes
// between two marks on top, both but for heapNoise (audit class GC-08: the
// sampled heap in use this replaces counted the tables a wide object's map
// outgrew and the arrays the decoder outgrew, garbage before anything is
// reserved, and reached 1.41 times the reservation under load); strings are
// charged their allocation size class, or below 16 bytes their share of
// the allocator's blocks (TestTinyBlocks).'''),
])

edit('fit_test.go', [
    ('''// it names, which the package documentation states ("Working set"), and
// reserves what the model charges, which covers its decoded tree and the
// live heap Handle holds at its peak, both measured after a collection, but
// for heapNoise (heapMeter, audit class GC-08); the log gives its
// reservation against that peak. The decision pass is reserved its worst''', '''// it names, which the package documentation states ("Working set"), and
// reserves what the model charges, which covers its decoded tree and the
// live heap Handle holds at its peak, both measured after a collection,
// the peak with the copies the passes make between two marks on top (the
// uniqueItems duplicates map among them), but for heapNoise (heapMeter,
// audit class GC-08); the log gives its reservation against that peak.
// Under -race, which measures nothing, it checks the outcome and the
// reservation alone. The decision pass is reserved its worst'''),
    ('''			// a collection, and the live heap Handle holds at its peak,
			// measured at the reservation and at the probes and matches
			// heapMeter spreads over the pass to its end, both but for
			// heapNoise (audit class GC-08: the sampled heap in use this
			// replaces counted the tables a wide object's map outgrew,
			// garbage before anything is reserved, and was allowed twice the
			// reservation).''', '''			// a collection, and the live heap Handle holds at its peak,
			// measured at the reservation and in the pass as heapMeter
			// schedules it, with the copies the pass makes between two
			// marks on top, both but for heapNoise (audit class GC-08: the
			// sampled heap in use this replaces counted the tables a wide
			// object's map outgrew, garbage before anything is reserved, and
			// was allowed twice the reservation; then the duplicates map of
			// the uniqueItems arrays, 58 bytes per item, which no probe saw,
			// was left out).'''),
    ('''// multiple of what Handle holds at its peak and covers it, but for
// heapNoise: the live heap at the reservation, at the probes of each pass
// and at their matches with each matcher's own peak on top (heapMeter, audit
// class GC-08; the sampled heap in use this replaces was allowed 1 MiB of
// slack over reservations of at most 384 KiB).''', '''// multiple of what Handle holds at its peak and covers it, but for
// heapNoise: the live heap at the reservation and in each pass as
// heapMeter schedules it, with the largest copy or matcher's own peak on
// top (audit class GC-08; the sampled heap in use this replaces was
// allowed 1 MiB of slack over reservations of at most 384 KiB).'''),
])
print('ok')
