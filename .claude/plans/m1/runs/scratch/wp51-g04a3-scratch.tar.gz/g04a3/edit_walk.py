import sys, os
root = sys.argv[1]


def edit(name, pairs):
    p = os.path.join(root, name)
    s = open(p, encoding='utf-8').read()
    for old, new in pairs:
        if s.count(old) != 1:
            raise SystemExit('%s: %d matches for %s' % (name, s.count(old), old[:120]))
        s = s.replace(old, new)
    open(p, 'w', encoding='utf-8', newline='\n').write(s)


edit('working.go', [
    ('''func (b *bodyScan) locateMemory() int64 {
	return addCap(addCap(b.locate, b.path), b.transient)
}''', '''func (b *bodyScan) locateMemory() int64 {
	return addCap(b.locate, max(addCap(b.path, b.transient), walkBytes(b.ws.flags.maxPointer)))
}'''),
    ('''// maxNumberWork is numberWork of the costliest literal within the number
// bounds.''', '''// walkBytes returns what the location walk holds at once besides the
// error tree, for a document whose error locations with their keywords
// take at most maxPointer bytes (locationOf, keywordAt): the best leaf's
// pointer so far, and for a leaf the pointer it builds, its location
// unescaped, then extended by each keyword token, the old string, the
// token escaped and the new string live at once while one is copied into
// the next, each rounded up to its allocation size (review finding, audit
// class GC-08: a document holding a location of 100,000 bytes held 300 KB
// in the walk of a failing body of one byte, which reserved 41 KB,
// TestHandleWalkMemory). The location pass's path and transient copies
// are gone by then, so the pass is charged the larger of the two
// (locateMemory).
func walkBytes(maxPointer int) int64 {
	n := int64(maxPointer)
	return 4 * (n + stringExtra(n))
}

// maxNumberWork is numberWork of the costliest literal within the number
// bounds.'''),
])

edit('meter_test.go', [
    ('''	// copyMatcher is a matcher's own peak.
	copyMatcher''', '''	// copyMatcher is a matcher's own peak.
	copyMatcher
	// copyWalk is the pointers the location walk builds (walkCopy).
	copyWalk'''),
    ('''// droppedErrors returns what the errors of a contains loop over false hold''', '''// walkCopy returns what the location walk over the error tree verr holds
// at once besides the tree (locationOf): for a leaf it builds a pointer
// for, what keywordAt allocates, all of it counted as live at once, with
// the largest pointer it may hold as the best leaf's on top. The walk runs
// after the location pass, where no probe runs; the package's own
// functions build the pointers, measured once per location and keyword.
func walkCopy(verr *sjs.ValidationError) int64 {
	built := map[string]bool{}
	var most, best int64
	leaves(verr, func(l *sjs.ValidationError) bool {
		loc, kw, ok := keywordParts(l)
		key := loc + "\\x00" + strings.Join(kw, "\\x00")
		if !ok || built[key] {
			return true
		}
		built[key] = true
		var p string
		var a, b runtime.MemStats
		gc := debug.SetGCPercent(-1)
		runtime.ReadMemStats(&a)
		p, _ = keywordAt(loc, kw)
		runtime.ReadMemStats(&b)
		debug.SetGCPercent(gc)
		most = max(most, int64(b.TotalAlloc-a.TotalAlloc))
		best = max(best, stringCopy(len(p)))
		return true
	})
	return most + best
}

// droppedErrors returns what the errors of a contains loop over false hold'''),
    ('''	} else {
		pf := probedFilter(t, f, schema, m)
		mx := &meterExchange{Exchange: x, m: m}
		m.start()
		r, reserved = pf.Handle(t.Context(), phase.OnRequestBody, mx), mx.peak
		m.check(t)
	}''', '''	} else {
		pf := probedFilter(t, f, schema, m)
		mx := &meterExchange{Exchange: x, m: m}
		m.start()
		r, reserved = pf.Handle(t.Context(), phase.OnRequestBody, mx), mx.peak
		m.check(t)
		// The location pass ran: its walk's pointers, replayed on the
		// tree of f's own location pass.
		if m.ends == 2 {
			v, _, err := f.decode([]byte(body))
			if err != nil {
				t.Fatal(err)
			}
			var verr *sjs.ValidationError
			if errors.As(f.schema.root.Validate(v), &verr) {
				m.copy(copyWalk, walkCopy(verr))
			}
		}
	}'''),
    ('''// handlePeak runs Handle in onRequestBody on a JSON body through f's
// probed copy (probedFilter), measuring with m: it returns the result and
// the largest reservation, and m's peak is the live heap growth at
// Handle's peak, marked at each reservation, which holds the decoded
// values, and in each pass as heapMeter schedules it, with the copies the
// passes made on top. Under -race it runs f itself and measures nothing
// (requireMeter).''', '''// handlePeak runs Handle in onRequestBody on a JSON body through f's
// probed copy (probedFilter), measuring with m: it returns the result and
// the largest reservation, and m's peak is the live heap growth at
// Handle's peak, marked at each reservation, which holds the decoded
// values, and in each pass as heapMeter schedules it, with the copies the
// passes made, and the location walk's pointers, on top. Under -race it
// runs f itself and measures nothing (requireMeter).'''),
    ('''import (
	"encoding/json"
	"fmt"''', '''import (
	"encoding/json"
	"errors"
	"fmt"'''),
])

edit('working_test.go', [
    ('''			ends := 0
			if s.root.Validate(v) != nil {
				ends = 1
			}''', '''			ends, walk := 0, int64(0)
			var verr *sjs.ValidationError
			if errors.As(s.root.Validate(v), &verr) {
				ends, walk = 1, walkCopy(verr)
			}'''),
    ('''				m.start()
				err := pass.s.Validate(v)
				peak := m.peak()
				runtime.KeepAlive(err)
				m.check(t)
				t.Logf("%s pass: charged %d''', '''				m.start()
				err := pass.s.Validate(v)
				if pass.name == "location" {
					m.copy(copyWalk, walk)
				}
				peak := m.peak()
				runtime.KeepAlive(err)
				m.check(t)
				t.Logf("%s pass: charged %d'''),
])
print('ok')
