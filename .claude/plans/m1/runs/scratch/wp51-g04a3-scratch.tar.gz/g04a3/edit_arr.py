import sys, os
root = sys.argv[1]


def edit(name, pairs):
    p = os.path.join(root, name)
    s = open(p, encoding='utf-8').read()
    for old, new in pairs:
        if s.count(old) != 1:
            raise SystemExit('%s: %d matches for %s' % (name, s.count(old), old[:120]))
        s = s.replace(old, new)
    open(p, 'w', encoding='utf-8', newline='\n').write(s)


edit('meter_test.go', [
    ('''// arrayBytes returns what an array of n items of E takes: its allocation
// size (allocSize), with the header the allocator puts in front of it past
// 512 bytes when E holds pointers.
func arrayBytes[E any](n int) int64 {
	typ := reflect.TypeFor[E]()
	bytes := int64(n) * int64(typ.Size())
	if pointers := typ.Kind() == reflect.String || typ.Kind() == reflect.Pointer; pointers && bytes > 512 {
		bytes += mallocHeaderBytes
	}
	return allocSize(bytes)
}''', '''// arrayBytes returns what an array of n items of E takes: its allocation
// size (allocSize), with the header the allocator puts in front of it past
// 512 bytes when E holds pointers (pointerSlice).
func arrayBytes[E any](n int) int64 {
	typ := reflect.TypeFor[E]()
	if typ.Kind() == reflect.String || typ.Kind() == reflect.Pointer {
		return pointerSlice(n, int64(typ.Size()))
	}
	return allocSize(int64(n) * int64(typ.Size()))
}'''),
    ('''			m := &heapMeter{}
			_, decide := probedSchemas(t, tc.schema, m)
			m.start()
			_ = decide.Validate(tc.v)
			if m.copies[tc.kind] != tc.want {
				t.Errorf("%s: copies %v, want %d of kind %d", tc.schema, m.copies, tc.want, tc.kind)
			}''', '''			m := &heapMeter{}
			_, decide := probedSchemas(t, tc.schema, m)
			m.start()
			_ = decide.Validate(tc.v)
			if m.copies[tc.kind] != tc.want || m.peak() < tc.want {
				t.Errorf("%s: copies %v, peak %d, want %d of kind %d at the peak", tc.schema, m.copies, m.peak(), tc.want, tc.kind)
			}'''),
])
print('ok')
