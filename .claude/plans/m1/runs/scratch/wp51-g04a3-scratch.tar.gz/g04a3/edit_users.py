import sys, os
root = sys.argv[1]


def edit(name, pairs):
    p = os.path.join(root, name)
    s = open(p, encoding='utf-8').read()
    for old, new in pairs:
        if old not in s:
            raise SystemExit('not found in %s: %s' % (name, old[:120]))
        if s.count(old) != 1:
            raise SystemExit('ambiguous in %s: %s' % (name, old[:120]))
        s = s.replace(old, new)
    open(p, 'w', encoding='utf-8', newline='\n').write(s)


edit('working_test.go', [
    ('''func TestDecisionTreeBesideCopies(t *testing.T) {
	const links, items = 6, 5000''', '''func TestDecisionTreeBesideCopies(t *testing.T) {
	requireMeter(t)
	const links, items = 6, 5000'''),
    ('''	schema := unevaluatedChain(100, "unevaluatedProperties")
	f = buildFilter(t, schema, 64<<20)
	m := &heapMeter{}
	r, reserved := handlePeak(t, f, schema, body, m)
	if r.Outcome != filter.Continue || reserved == 0 {
		t.Fatalf("Handle at 64 MiB = %+v, reserved %d, want Continue", r, reserved)
	}
	// The deepest link, the first probe, holds the 100 copies.''', '''	schema := unevaluatedChain(100, "unevaluatedProperties")
	f = buildFilter(t, schema, 64<<20)
	m := &heapMeter{}
	r, reserved := handlePeak(t, f, schema, body, m)
	if r.Outcome != filter.Continue || reserved == 0 {
		t.Fatalf("Handle at 64 MiB = %+v, reserved %d, want Continue", r, reserved)
	}
	if _, scan := scanBody(t, f.schema, body); scan.path < 100*2000*propMapEntry {
		t.Errorf("the path charges %d bytes, less than the 100 copies of 2,000 names", scan.path)
	}
	requireMeter(t)
	// The deepest link, the first exit probe, holds the 100 copies.'''),
    ('''	if exceeds(m.peak(), reserved) {
		t.Errorf("Handle held %d bytes at its peak, reserved %d", m.peak(), reserved)
	}
	if _, scan := scanBody(t, f.schema, body); scan.path < 100*2000*propMapEntry {
		t.Errorf("the path charges %d bytes, less than the 100 copies of 2,000 names", scan.path)
	}
}''', '''	if exceeds(m.peak(), reserved) {
		t.Errorf("Handle held %d bytes at its peak, reserved %d", m.peak(), reserved)
	}
}'''),
    ('''			r, reserved := handlePeak(t, f, schema, tc.body, m)
			if r.Outcome != filter.Continue {
				t.Fatalf("Handle at 64 MiB = %+v, want Continue", r)
			}
			deepest := m.at["/$defs/c3"]''', '''			r, reserved := handlePeak(t, f, schema, tc.body, m)
			if r.Outcome != filter.Continue {
				t.Fatalf("Handle at 64 MiB = %+v, want Continue", r)
			}
			requireMeter(t)
			deepest := m.at["/$defs/c3"]'''),
    ('''	if got := detailOf(t, r); got != DetailMismatch+" at /$defs/d0/maxContains" {
		t.Fatalf("detail = %q, want the location of maxContains", got)
	}
	// The location pass ends at the root, its probe holding the lists of
	// the whole chain.''', '''	if got := detailOf(t, r); got != DetailMismatch+" at /$defs/d0/maxContains" {
		t.Fatalf("detail = %q, want the location of maxContains", got)
	}
	if _, scan := scanBody(t, f.schema, body); scan.locate < int64(100*n*8) {
		t.Errorf("the location pass is charged %d bytes, less than the 100 lists of %d indexes", scan.locate, n)
	}
	requireMeter(t)
	// The location pass ends at the root, its exit probe holding the lists
	// of the whole chain.'''),
    ('''	if exceeds(m.peak(), reserved) {
		t.Errorf("Handle held %d bytes at its peak, reserved %d", m.peak(), reserved)
	}
	if _, scan := scanBody(t, f.schema, body); scan.locate < int64(100*n*8) {
		t.Errorf("the location pass is charged %d bytes, less than the 100 lists of %d indexes", scan.locate, n)
	}
}''', '''	if exceeds(m.peak(), reserved) {
		t.Errorf("Handle held %d bytes at its peak, reserved %d", m.peak(), reserved)
	}
}'''),
    ('''func TestHandleBoundsValidationMemory(t *testing.T) {
	schema := `{"type":"array","items":` + oneOfConsts(8) + `}`
	f := buildFilter(t, schema, 4<<20)
	m := &heapMeter{}
	r, reserved := handlePeak(t, f, schema, denseArray(5000, `"x"`, 0), m)
	if got := detailOf(t, r); got != DetailMismatch+" at /items/oneOf/0/const" {
		t.Fatalf("detail = %q", got)
	}
	t.Logf("live peak %d, reserved %d (%.2f)", m.peak(), reserved, float64(m.peak())/float64(reserved))
	if len(m.at[""]) != 1 {
		t.Errorf("the location pass reached its root %d times, want once", len(m.at[""]))
	}
	if reserved == 0 || exceeds(m.peak(), reserved) {
		t.Errorf("Handle held %d bytes at its peak, reserved %d", m.peak(), reserved)
	}

	// 1,000,000 items at the 10 MiB default: the decode fits (33 MiB of
	// the 40 MiB budget), validation could hold gigabytes.
	var before, after runtime.MemStats
	big := []byte(denseArray(1_000_000, `"x"`, 0))
	f = buildFilter(t, schema, 0)''', '''func TestHandleBoundsValidationMemory(t *testing.T) {
	schema := `{"type":"array","items":` + oneOfConsts(8) + `}`
	// 1,000,000 items at the 10 MiB default: the decode fits (33 MiB of
	// the 40 MiB budget), validation could hold gigabytes.
	var before, after runtime.MemStats
	big := []byte(denseArray(1_000_000, `"x"`, 0))
	f := buildFilter(t, schema, 0)
	var r filter.Result'''),
    ('''	if x.Budget.Reserved != 0 {
		t.Errorf("reservation left: %d", x.Budget.Reserved)
	}
}

// TestWorkingSetCharges pins the working-set model''', '''	if x.Budget.Reserved != 0 {
		t.Errorf("reservation left: %d", x.Budget.Reserved)
	}

	f = buildFilter(t, schema, 4<<20)
	m := &heapMeter{}
	r, reserved := handlePeak(t, f, schema, denseArray(5000, `"x"`, 0), m)
	if got := detailOf(t, r); got != DetailMismatch+" at /items/oneOf/0/const" || reserved == 0 {
		t.Fatalf("detail = %q, reserved %d", got, reserved)
	}
	requireMeter(t)
	t.Logf("live peak %d, reserved %d (%.2f)", m.peak(), reserved, float64(m.peak())/float64(reserved))
	if len(m.at[""]) != 1 || len(m.at[endMark]) != 2 {
		t.Errorf("the location pass reached its root %d times, the passes ended %d times; want once and twice", len(m.at[""]), len(m.at[endMark]))
	}
	if exceeds(m.peak(), reserved) {
		t.Errorf("Handle held %d bytes at its peak, reserved %d", m.peak(), reserved)
	}
}

// TestWorkingSetCharges pins the working-set model'''),
    ('''	t.Logf("body %d bytes: reserved %d (decoded values included), live peak %d (%.2f)", len(body), reserved, m.peak(), float64(reserved)/float64(m.peak()))
	if float64(reserved) > 2.5*float64(m.peak()) {''', '''	requireMeter(t)
	t.Logf("body %d bytes: reserved %d (decoded values included), live peak %d (%.2f)", len(body), reserved, m.peak(), float64(reserved)/float64(m.peak()))
	if float64(reserved) > 2.5*float64(m.peak()) {'''),
])

edit('regexcost_test.go', [
    ('''			} else if got := detailOf(t, r); got != DetailMismatch+" at "+tc.detail {
				t.Fatalf("detail = %q, want the location %s", got, tc.detail)
			}
			t.Logf("reserved %d, live peak %d, of which the matcher %d", reserved, m.peak(), m.matcher)
			// The measurement sees the job stack''', '''			} else if got := detailOf(t, r); got != DetailMismatch+" at "+tc.detail {
				t.Fatalf("detail = %q, want the location %s", got, tc.detail)
			}
			requireMeter(t)
			t.Logf("reserved %d, live peak %d, of which the matcher %d", reserved, m.peak(), m.matcher)
			// The measurement sees the job stack'''),
])

edit('fit_test.go', [
    ('''			t.Logf("%d bytes: reserved %d, live peak %d, of which the matcher %d", len(tc.body), reserved, m.peak(), m.matcher)
			if reserved > tc.most {
				t.Errorf("reserved %d, want at most %d", reserved, tc.most)
			}
			if exceeds(m.peak(), reserved) {''', '''			if reserved > tc.most {
				t.Errorf("reserved %d, want at most %d", reserved, tc.most)
			}
			requireMeter(t)
			t.Logf("%d bytes: reserved %d, live peak %d, of which the matcher %d", len(tc.body), reserved, m.peak(), m.matcher)
			if exceeds(m.peak(), reserved) {'''),
    ('''			peak := m.peak()
			t.Logf("body %.3f of the limit: reserved %.2f times the limit, %.2f times the live peak %d", float64(len(tc.body))/float64(limit), float64(reserved)/float64(limit), float64(reserved)/float64(peak), peak)
			// Minor review finding''', '''			// Minor review finding'''),
    ('''			if want := cost + scan.extra + scan.decideMemory(); reserved != want {
				t.Errorf("reserved %d, the model charges %d", reserved, want)
			}
			base := liveHeap()
			v, cost, _ = f.decode([]byte(tc.body))
			live := growth(liveHeap(), base)
			runtime.KeepAlive(v)
			if raceEnabled {
				live -= raceTinyBytes(v)
				peak -= raceTinyBytes(v)
			}
			if exceeds(live, cost+scan.extra) {''', '''			if want := cost + scan.extra + scan.decideMemory(); reserved != want {
				t.Errorf("reserved %d, the model charges %d", reserved, want)
			}
			requireMeter(t)
			peak := m.peak()
			t.Logf("body %.3f of the limit: reserved %.2f times the limit, %.2f times the live peak %d, copies %v", float64(len(tc.body))/float64(limit), float64(reserved)/float64(limit), float64(reserved)/float64(peak), peak, m.copies)
			base := liveHeap()
			v, cost, _ = f.decode([]byte(tc.body))
			live := growth(liveHeap(), base)
			runtime.KeepAlive(v)
			if exceeds(live, cost+scan.extra) {'''),
])

edit('work_limit_test.go', [
    ('''			_, scan := scanBody(t, f.schema, tc.body)
			peak := m.peak()
			t.Logf("body %d bytes: reserved %d, live peak %d (%.2f), work %d of %d", len(tc.body), reserved, peak, float64(reserved)/float64(peak), scan.work, f.limits.work)
			if float64(reserved) > tc.most*float64(peak) {
				t.Errorf("reserved %d, more than %.1f times the live peak %d", reserved, tc.most, peak)
			}
			if _, cost, _ := f.decode([]byte(tc.body)); reserved != cost+scan.extra+scan.decideMemory() {
				t.Errorf("reserved %d, want the decoded values %d, their maps and arrays %d and the decision pass's working set %d", reserved, cost, scan.extra, scan.decideMemory())
			}''', '''			_, scan := scanBody(t, f.schema, tc.body)
			if _, cost, _ := f.decode([]byte(tc.body)); reserved != cost+scan.extra+scan.decideMemory() {
				t.Errorf("reserved %d, want the decoded values %d, their maps and arrays %d and the decision pass's working set %d", reserved, cost, scan.extra, scan.decideMemory())
			}
			requireMeter(t)
			peak := m.peak()
			t.Logf("body %d bytes: reserved %d, live peak %d (%.2f), work %d of %d, copies %v", len(tc.body), reserved, peak, float64(reserved)/float64(peak), scan.work, f.limits.work, m.copies)
			if float64(reserved) > tc.most*float64(peak) {
				t.Errorf("reserved %d, more than %.1f times the live peak %d", reserved, tc.most, peak)
			}
			if exceeds(peak, reserved) {
				t.Errorf("Handle held %d bytes at its peak, reserved %d", peak, reserved)
			}'''),
    ('''			r, reserved := handlePeak(t, f, tc.schema, tc.body, m)
			if r.Outcome != filter.Continue {
				t.Fatalf("Handle = %+v, want Continue", r)
			}
			base := liveHeap()
			v, cost, err := f.decode([]byte(tc.body))
			live := growth(liveHeap(), base)
			runtime.KeepAlive(v)
			if err != nil {
				t.Fatal(err)
			}
			_, scan := scanBody(t, f.schema, tc.body)
			peak := m.peak()
			if raceEnabled {
				// The race detector turns off the allocator's packing of
				// small strings: each takes a size class of its own.
				live -= raceTinyBytes(v)
				peak -= raceTinyBytes(v)
			}
			t.Logf(''', '''			r, reserved := handlePeak(t, f, tc.schema, tc.body, m)
			if r.Outcome != filter.Continue {
				t.Fatalf("Handle = %+v, want Continue", r)
			}
			requireMeter(t)
			base := liveHeap()
			v, cost, err := f.decode([]byte(tc.body))
			live := growth(liveHeap(), base)
			runtime.KeepAlive(v)
			if err != nil {
				t.Fatal(err)
			}
			_, scan := scanBody(t, f.schema, tc.body)
			peak := m.peak()
			t.Logf('''),
    ('''// raceTinyBytes returns what a -race build's allocator adds to the decoded
// strings, member names and number literals of v beyond their charge: it
// gives every allocation shorter than 16 bytes a block of its own, the
// runtime's static one-byte strings aside.
func raceTinyBytes(v any) int64 {
	var n int64
	eachString(v, func(size int) {
		if size > 1 && size < tinyBlockBytes {
			n += tinyBlockBytes - int64(size) - stringExtra(int64(size))
		}
	})
	return n
}

// eachString calls f with the length of every string, member name and
// number literal of v.
func eachString(v any, f func(size int)) {
	switch t := v.(type) {
	case string:
		f(len(t))
	case json.Number:
		f(len(t))
	case []any:
		for _, e := range t {
			eachString(e, f)
		}
	case map[string]any:
		for k, e := range t {
			f(len(k))
			eachString(e, f)
		}
	}
}

''', ''),
])

edit('states_test.go', [
    ('''			if decide := decisionTree(t, tc.schema, v); decide > scan.decide+treeSlack {
				t.Errorf("the decision pass held an error tree of %d bytes, the scan charges %d", decide, scan.decide)
			}''', '''			requireMeter(t)
			if decide := decisionTree(t, tc.schema, v); decide > scan.decide+treeSlack {
				t.Errorf("the decision pass held an error tree of %d bytes, the scan charges %d", decide, scan.decide)
			}'''),
])
print('ok')
