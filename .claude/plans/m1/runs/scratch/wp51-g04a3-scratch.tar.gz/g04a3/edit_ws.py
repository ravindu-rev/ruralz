import sys
p = sys.argv[1]
s = open(p, encoding='utf-8').read()
old_head = '''// workingSetCases are dense bodies, each against a schema that fails at
// every value in a different way, or (the unevaluated shapes) holds the
// library's copies of member names or item indexes along a reference
// chain, or (the ordinary shapes) a valid or failing order body.
func workingSetCases() []struct{ name, schema, body string } {
	// denseArray, with a quarter of the items under -race, which slows the
	// library tenfold: the trees are measured exactly at any size.
	denseArray := func(n int, item string, depth int) string {
		if raceEnabled {
			n = max(n/4, 1)
		}
		return denseArray(n, item, depth)
	}
	var required, members []string'''
new_head = '''// distinct returns an array of n items made by formatting i, from 0 to
// n-1, with format.
func distinct(n int, format string) string {
	return "[" + joined(n, func(i int) string { return fmt.Sprintf(format, i) }) + "]"
}

// workingSetCases are dense bodies, each against a schema that fails at
// every value in a different way, or (the unevaluated shapes) holds the
// library's copies of member names or item indexes along a reference
// chain, or (the ordinary shapes) a valid or failing order body, or (the
// copies) makes a copy that it drops before any probe runs again.
func workingSetCases() []struct{ name, schema, body string } {
	var required, members []string'''
assert old_head in s
s = s.replace(old_head, new_head)
old_tail = '''		{"property names under mixins", strings.TrimSuffix(mixins, "}") + `,"propertyNames":{"allOf":[` + strings.TrimSuffix(strings.Repeat(`{"pattern":"^a","maxLength":2},`, 20), ",") + `]}}`, wideObject(2000)},
	}
}'''
new_tail = '''		{"property names under mixins", strings.TrimSuffix(mixins, "}") + `,"propertyNames":{"allOf":[` + strings.TrimSuffix(strings.Repeat(`{"pattern":"^a","maxLength":2},`, 20), ",") + `]}}`, wideObject(2000)},
		// Review finding (audit class GC-08): the copies the library makes
		// and drops between two probes, which the meter replays. The
		// uniqueItems check of distinct integers, strings and objects, of
		// numbers that hash alike (a number and its negation), of an array
		// whose last item repeats the first, and of a wide object among the
		// items, whose names it sorts.
		{"unique integers", `{"uniqueItems":true}`, distinct(20000, "%d")},
		{"unique strings", `{"uniqueItems":true}`, distinct(20000, `"s%05d"`)},
		{"unique objects", `{"uniqueItems":true}`, distinct(10000, `{"id":%d,"name":"item"}`)},
		{"numbers that hash alike", `{"uniqueItems":true}`, "[" + joined(20000, func(i int) string { return fmt.Sprint((i/2 + 1) * (1 - 2*(i%2))) }) + "]"},
		{"a duplicate at the end", `{"uniqueItems":true}`, strings.TrimSuffix(distinct(20000, "%d"), "]") + ",0]"},
		{"names of hashed objects", `{"uniqueItems":true}`, "[" + wideObject(50000) + "," + strings.TrimPrefix(distinct(20, "%d"), "[")},
		// A string's copy at every evaluation; the names additionalProperties
		// false lists, the duplicates map, and the errors of contains over
		// false, each in an evaluation that drops them, the first two in a
		// failing branch of a valid body, where no exit probe runs.
		{"long strings", `{"items":{"type":"string"}}`, denseArray(8, `"`+strings.Repeat("s", 100000)+`"`, 0)},
		{"undeclared members in a failing branch", `{"anyOf":[{"additionalProperties":false},true]}`, wideObject(20000)},
		{"duplicates in a failing branch", `{"anyOf":[{"uniqueItems":true,"maxItems":1},true]}`, distinct(20000, "%d")},
		{"errors contains drops", `{"contains":false,"minContains":0}`, denseArray(20000, `1`, 0)},
	}
}'''
assert old_tail in s
s = s.replace(old_tail, new_tail)
a = s.index('// TestWorkingSetCoversPeak covers the working-set bound')
b = s.index('// treeApart sets how far apart two validations')
new_test = open(sys.argv[2], encoding='utf-8').read()
s = s[:a] + new_test + s[b:]
open(p, 'w', encoding='utf-8', newline='\n').write(s)
