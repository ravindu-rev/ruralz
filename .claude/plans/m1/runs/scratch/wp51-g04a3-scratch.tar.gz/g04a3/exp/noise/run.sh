#!/bin/bash
# heapNoise on one processor: 3 processes per toolchain, each 9,000
# measurements of a loop that keeps nothing new, beside four busy loops.
N=/c/Users/ravin/AppData/Local/Temp/claude/c--Users-ravin-Projects-Ruralz/5104a226-9733-4230-8cf6-a5ff30e79ceb/scratchpad/wp51close/g04a3/exp/noise
PKG=/c/Users/ravin/Projects/Ruralz/internal/filter/validation/jsonschema
busy=()
for i in 1 2 3 4; do ( while :; do :; done ) & busy+=($!); done
pids=()
for bin in n127 n126; do
	for i in 1 2 3; do
		( cd $PKG && $N/$bin.test.exe -test.run '^TestG04Noise$' -test.count=1 > $N/$bin.$i.out 2>&1 ) &
		pids+=($!)
	done
done
for p in "${pids[@]}"; do wait $p; done
kill "${busy[@]}" 2>/dev/null
for f in $N/n12*.out; do echo "$(basename $f): $(grep NOISE $f | tr '\n' ' ') $(tail -1 $f)"; done
