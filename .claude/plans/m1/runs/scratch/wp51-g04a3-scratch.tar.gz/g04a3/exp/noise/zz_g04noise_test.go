// Copyright 2026 Revington
// SPDX-License-Identifier: Apache-2.0

package jsonschema

import (
	"fmt"
	"runtime"
	"slices"
	"testing"
)

// TestG04Noise measures, on the meter's one processor (requireMeter), the
// live heap growth of 9,000 measurements of a loop that keeps nothing new,
// as heapNoise states it.
func TestG04Noise(t *testing.T) {
	requireMeter(t)
	fmt.Printf("NOISE procs %d\n", runtime.GOMAXPROCS(0))
	sink := make([][]byte, 64)
	var growths []int64
	for range 9000 {
		m := &heapMeter{}
		m.start()
		for j := range sink {
			sink[j] = make([]byte, 16+j)
		}
		clear(sink)
		m.mark("")
		growths = append(growths, m.at[""][0])
	}
	slices.Sort(growths)
	n := len(growths)
	fmt.Printf("NOISE min %d p50 %d p99 %d p999 %d max %d\n", growths[0], growths[n/2], growths[n*99/100], growths[n*999/1000], growths[n-1])
}
