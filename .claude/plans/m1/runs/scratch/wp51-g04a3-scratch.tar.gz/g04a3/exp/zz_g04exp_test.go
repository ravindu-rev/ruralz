// Copyright 2026 Revington
// SPDX-License-Identifier: Apache-2.0

package jsonschema

import (
	"runtime"
	"runtime/debug"
	"strconv"
	"testing"
)

func TestG04ExpMapMargins(t *testing.T) {
	allocated := func(f func()) int64 {
		var a, b runtime.MemStats
		gc := debug.SetGCPercent(-1)
		runtime.ReadMemStats(&a)
		f()
		runtime.ReadMemStats(&b)
		debug.SetGCPercent(gc)
		return growth(b.TotalAlloc, a.TotalAlloc)
	}
	var names []string
	for i := range 1 << 17 {
		names = append(names, "m"+strconv.Itoa(i))
	}
	worst := map[string]float64{}
	for _, n := range []int{1, 2, 7, 8, 9, 13, 14, 15, 27, 28, 29, 55, 56, 57, 111, 112, 113, 223, 224, 225, 447, 448, 449, 895, 896, 897, 898, 1000, 1792, 1793, 2000, 3585, 5000, 7169, 10000, 14337, 28673, 50000, 57345, 100000, 1 << 17} {
		for rep := 0; rep < 15; rep++ {
			props := allocated(func() {
				m := map[string]struct{}{}
				for _, name := range names[:n] {
					m[name] = struct{}{}
				}
			})
			items := allocated(func() {
				m := map[int]struct{}{}
				for i := range n {
					m[i] = struct{}{}
				}
			})
			dups := allocated(func() {
				m := make(map[uint64][]int)
				for i := range n {
					m[uint64(i)] = append(m[uint64(i)], i)
				}
			})
			worst["props"] = max(worst["props"], float64(props)/float64(propMapBase+propMapEntry*n))
			worst["items"] = max(worst["items"], float64(items)/float64(itemMapBase+itemMapEntry*n))
			if n > pairwiseItems {
				worst["dups"] = max(worst["dups"], float64(dups)/float64(dupItemBytes*n))
			}
		}
	}
	t.Logf("worst allocation over charge: %v", worst)
}
