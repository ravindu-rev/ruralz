"""Reflow one comment paragraph or bullet of a Go file to 80 columns.

Usage: reflow.py FILE START_TEXT END_TEXT
The block is the lines from the first line containing START_TEXT to the
first following line containing END_TEXT, inclusive. Every line must be a
comment with the same indentation; the first line's prefix (for example
"//   - ") is kept, and continuation lines get the second line's prefix (for
example "//     ").
"""
import re
import sys

path, start, end = sys.argv[1], sys.argv[2], sys.argv[3]
WIDTH = 80
lines = open(path, encoding='utf-8').read().split('\n')
a = next(i for i, l in enumerate(lines) if start in l)
b = next(i for i in range(a, len(lines)) if end in lines[i])
block = lines[a:b + 1]
m0 = re.match(r'^(\s*//\s*(?:- )?)', block[0])
first_prefix = m0.group(1)
if len(block) > 1:
    cont_prefix = re.match(r'^(\s*//\s*)', block[1]).group(1)
else:
    cont_prefix = first_prefix
words = []
for i, l in enumerate(block):
    p = first_prefix if i == 0 else re.match(r'^(\s*//\s*)', l).group(1)
    words.extend(l[len(p):].split())
out, cur = [], first_prefix
for w in words:
    candidate = cur + ('' if cur == first_prefix or cur == cont_prefix else ' ') + w
    if len(candidate) > WIDTH and cur not in (first_prefix, cont_prefix):
        out.append(cur)
        cur = cont_prefix + w
    else:
        cur = candidate
out.append(cur)
lines[a:b + 1] = out
open(path, 'w', encoding='utf-8', newline='\n').write('\n'.join(lines))
print('reflowed %d lines into %d' % (b - a + 1, len(out)))
