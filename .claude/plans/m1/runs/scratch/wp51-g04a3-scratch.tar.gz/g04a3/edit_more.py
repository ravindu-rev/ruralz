import sys, os
root = sys.argv[1]


def edit(name, pairs):
    p = os.path.join(root, name)
    s = open(p, encoding='utf-8').read()
    for old, new in pairs:
        if s.count(old) != 1:
            raise SystemExit('%s: %d matches for %s' % (name, s.count(old), old[:120]))
        s = s.replace(old, new)
    open(p, 'w', encoding='utf-8', newline='\n').write(s)


edit('meter_test.go', [
    ('''	t.Run("copies", func(t *testing.T) {
		const n = 1 << 20''', '''	t.Run("NFA matches past the head", func(t *testing.T) {
		// Inputs of 60,000 bytes, past the backtracker's 52,428 for the
		// program of ^a+$: every match runs on the NFA simulation.
		schema := `{"items":{"pattern":"^a+$"}}`
		v, _ := scanBody(t, mustCompile(t, schema), denseArray(30, `"`+strings.Repeat("a", 60000)+`"`, 0))
		m := &heapMeter{}
		_, decide := probedSchemas(t, schema, m)
		m.start()
		_ = decide.Validate(v)
		m.check(t)
		if m.byPass[0].matches != 30 {
			t.Errorf("%d of 30 matches on the NFA simulation metered, want all", m.byPass[0].matches)
		}
	})
	t.Run("copies", func(t *testing.T) {
		const n = 1 << 20'''),
    ('''//   - A match whose job stack is larger than at every metered match of its
//     pattern is metered wherever it falls in the pass.''', '''//   - A match whose job stack is larger than at every metered match of its
//     pattern is metered wherever it falls in the pass, and so is every
//     match on the NFA simulation.'''),
])

edit('working_test.go', [
    ('''		"errors contains drops":                  {copyDropped, 20000 * 80},
		"numbers":                                {copyNumber, numberCheckBytes},
	}''', '''		"errors contains drops":                  {copyDropped, 20000 * 80},
		"numbers":                                {copyNumber, numberCheckBytes},
	}
	// The rows whose decision pass holds a list in the middle of the pass,
	// with the least live heap growth a mark measures there: the matching
	// items of the chain's contains, which is true, four fifths of one list
	// of 16,000 indexes (review finding: true got no probe, so no mark
	// measured the list).
	holds := map[string]int64{"matching items along a chain": 16000 * 8 * 4 / 5}'''),
    ('''				if c, ok := copies[tc.name]; ok && m.copies[c.kind] < c.least {
					t.Errorf("the %s pass replayed copies %v, want at least %d of kind %d", pass.name, m.copies, c.least, c.kind)
				}''', '''				if c, ok := copies[tc.name]; ok && m.copies[c.kind] < c.least {
					t.Errorf("the %s pass replayed copies %v, want at least %d of kind %d", pass.name, m.copies, c.least, c.kind)
				}
				if least, ok := holds[tc.name]; ok && pass.name == "decision" && growth(m.live, m.base) < least {
					t.Errorf("the decision pass measured at most %d bytes live, want at least %d of a list", growth(m.live, m.base), least)
				}'''),
])
print('ok')
