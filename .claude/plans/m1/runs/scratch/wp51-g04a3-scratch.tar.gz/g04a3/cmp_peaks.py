import re, sys
def load(path):
    out = {}
    name = None
    for line in open(path, encoding='utf-8', errors='replace'):
        m = re.match(r'\s*=== RUN\s+(\S+)', line)
        if m:
            name = m.group(1)
            continue
        m = re.search(r'(decision|location) pass: charged (\d+), live peak (\d+)', line)
        if m and name:
            out[(name, m.group(1))] = (int(m.group(2)), int(m.group(3)))
            continue
        m = re.search(r'live peak (\d+)', line)
        if m and name:
            out.setdefault((name, 'peak'), (0, int(m.group(1))))
    return out
a, b = load(sys.argv[1]), load(sys.argv[2])
worst = []
for k in sorted(set(a) & set(b)):
    pa, pb = a[k][1], b[k][1]
    if max(pa, pb) == 0:
        continue
    d = (pb - pa) / max(pa, 1)
    worst.append((abs(pb - pa), d, k, pa, pb))
worst.sort(reverse=True)
print(len(worst), 'compared')
for w in worst[:25]:
    print('%10d %+.4f %-70s %s %d -> %d' % (w[0], w[1], w[2][0][:70], w[2][1], w[3], w[4]))
