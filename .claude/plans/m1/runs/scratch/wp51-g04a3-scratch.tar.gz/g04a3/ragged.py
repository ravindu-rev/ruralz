"""Report comment lines that end early: the next line of the same
paragraph starts with a word that would have fit within 80 columns.

Bullets ("- " after the comment marker) start a new paragraph, as do blank
comment lines and lines whose indentation differs. A line counts tabs as one
column, as the package's width check does.
"""
import re
import sys

WIDTH = 80
for path in sys.argv[1:]:
    lines = open(path, encoding='utf-8').read().split('\n')
    for i in range(len(lines) - 1):
        a, b = lines[i], lines[i + 1]
        ma = re.match(r'^(\s*//)( *)(.*)$', a)
        mb = re.match(r'^(\s*//)( *)(.*)$', b)
        if not ma or not mb:
            continue
        if ma.group(1) != mb.group(1):
            continue
        ta, tb = ma.group(3), mb.group(3)
        if not ta.strip() or not tb.strip():
            continue
        if tb.startswith('- ') or ta.startswith('nolint') or tb.startswith('nolint'):
            continue
        if ta.startswith('go:') or tb.startswith('go:'):
            continue
        # The continuation's indentation must match the line's text column
        # (a bullet's continuation is indented two more).
        ia = len(ma.group(2)) + (2 if ta.startswith('- ') else 0)
        ib = len(mb.group(2))
        if ia != ib:
            continue
        word = tb.split()[0]
        if len(a) + 1 + len(word) <= 70:
            print('%s:%d: %d cols, next word %r fits' % (path, i + 1, len(a), word))
