import sys
p = sys.argv[1]
s = open(p, encoding='utf-8').read()
def rep(old, new):
    global s
    assert old in s, old[:80]
    s = s.replace(old, new)
rep('''// meteredPattern is a pattern of a probed compile whose matches mark the
// meter: the live heap at the match, whose collections empty the pools of
// Go's regexp, so that the match starts from nothing as after any
// collection, and the matcher's own peak on top of it (matcherPeak). A
// match is metered when due, when it is its pattern's first in the
// measurement, and when its input is longer, or its replayed job stack
// larger, than every metered match's of the pattern; every other match
// of the backtracker records its own peak replayed from the job stack
// (backtrackPeak), so that the largest matcher is measured whichever
// match holds it (review finding: matches only at the head of a pass and
// spread over it missed a longer input elsewhere).''', '''// meteredPattern is a pattern of a probed compile whose matches mark the
// meter: the live heap at the match, whose collections empty the pools of
// Go's regexp, so that the match starts from nothing as after any
// collection, and the matcher's own peak on top of it (matcherPeak). A
// match is metered when due, when it runs on the NFA simulation, and when
// the backtracker's job stack, replayed (backtrackJobs), holds more jobs
// than at every metered match of its pattern in the measurement, so that
// the largest matcher is measured whichever match holds it (review
// finding: marks at the head of a pass and spread over it alone missed a
// longer input elsewhere): the backtracker's own peak grows with its job
// stack alone, its visited set being allocated at its largest whatever
// the input, and Go's regexp runs the NFA simulation only on inputs of at
// least maxBacktrackVector bits divided by the program's instructions,
// few in a body, whose machine and threads it allocates by the program.''')
rep('''	// records holds the input and job stack of the largest metered match
	// of each pattern in the measurement; sizes and duplicates cache the
	// allocation sizes and the duplicates copies replayed.
	records    map[*meteredPattern]matchRecord''', '''	// jobs holds the most jobs of the backtracker at a metered match of
	// each pattern in the measurement; sizes and duplicates cache the
	// allocation sizes and the duplicates copies replayed.
	jobs       map[*meteredPattern]int''')
rep('''// matchRecord is the largest input and job stack a pattern's metered
// matches met.
type matchRecord struct {
	seen        bool
	input, jobs int
}

''', '')
rep('''	m.records = map[*meteredPattern]matchRecord{}''', '''	m.jobs = map[*meteredPattern]int{}''')
rep('''	m := p.m
	m.matches++
	jobs := -1
	if n := len(p.prog.Inst); n <= maxBacktrackProg && len(s) < maxBacktrackVector/n {
		jobs = backtrackJobs(p.prog, s)
	}
	rec := m.records[p]
	if !due(m.matches, &m.nextMatch) && rec.seen && len(s) <= rec.input && jobs <= rec.jobs {
		if jobs >= 0 {
			m.copy(copyMatcher, backtrackPeak(jobs))
		}
		return p.compiledPattern.MatchString(s)
	}
	m.records[p] = matchRecord{seen: true, input: max(rec.input, len(s)), jobs: max(rec.jobs, jobs)}
''', '''	m := p.m
	m.matches++
	jobs := -1
	if n := len(p.prog.Inst); n <= maxBacktrackProg && len(s) < maxBacktrackVector/n {
		jobs = backtrackJobs(p.prog, s)
	}
	if most, seen := m.jobs[p]; !due(m.matches, &m.nextMatch) && jobs >= 0 && seen && jobs <= most {
		return p.compiledPattern.MatchString(s)
	}
	m.jobs[p] = max(m.jobs[p], jobs)
''')
rep('''// backtrackPeak returns the backtracker's own peak on an input on which
// its stack holds jobs jobs, as matcherPeak accepts it at the most: its
// state and the largest pair of job arrays.
func backtrackPeak(jobs int) int64 {
	_, pair := jobArrays(jobs)
	return backtrackState() + pair
}

''', '')
open(p, 'w', encoding='utf-8', newline='\n').write(s)
